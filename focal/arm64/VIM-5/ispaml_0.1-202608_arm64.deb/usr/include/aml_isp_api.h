/*
 * Copyright (C) 2019-2024 Amlogic, Inc. All rights reserved.
 *
 * All information contained herein is Amlogic confidential.
 *
 * T_s software is provided to you pursuant to Software License Agreement
 * (SLA) with Amlogic Inc ("Amlogic"). T_s software may be used
 * only in accordance with the terms of t_s agreement.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification is strictly prohbited without prior written permission from
 * Amlogic.
 *
 * TMBPS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF TMBPS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __AML_ISP_API_H__
#define __AML_ISP_API_H__

#include "aml_comm_isp.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

typedef enum
{
    AML_CMD_GET = 0x0,
    AML_CMD_SET,
} aisp_cmd_type_t;

struct aml_format {
    uint32_t xstart;
    uint32_t ystart;
    uint32_t width;
    uint32_t height;
    uint32_t code;
    uint32_t fourcc;
    uint32_t nplanes;
    uint32_t bpp;
    uint32_t cwidth;
    uint32_t cheight;
    uint32_t fps;
};

typedef struct _image_resolution_t {
	uint32_t width;
	uint32_t height;
} image_resolution_t;

// this structure represents image resolution
// it is used in sensor driver to keep information
// about the frame width and frame height
typedef struct _IMAGE_RESOLUTION_T {
    MBP_U32 u32Width;
    MBP_U32 u32Height;
} IMAGE_RESOLUTION_T;

// a sensor can support several different predefined modes.
// this structure keeps all necessary information about a mode
typedef struct _SENSOR_MODE_T {
    MBP_U8 u8WdrMode;              // The wdr mode.
    MBP_U32 u32fps;                  // Fps value multiplied by 256
    IMAGE_RESOLUTION_T stResolution; // Resolution of the mode
    MBP_U8 u8Exposures;             // How many exposures this mode supports
    MBP_U8 u8Gains;                  // How many different gain this mode supports
    MBP_U8 u8bits;                  // Bit depth of data from sensor
    MBP_U8 u8RawMode;              // 0: mono 1: RGB-raw
    MBP_U8 u8Pattern;               //
} SENSOR_MODE_T;

typedef struct _focus_tab_s {
    uint32_t focal_len;              /**< READONLY u32, current focal length of the lens (mm x 10000) */
    uint16_t macro_limit_idx;        /**< READONLY u32, lens position on the focus macro (steps) */
    uint16_t focus_7cm_idx;          /**< READONLY u32, lens position on the focus 7cm (steps) */
    uint16_t focus_10cm_idx;         /**< READONLY u32, lens position on the focus 10cm (steps) */
    uint16_t focus_14cm_idx;         /**< READONLY u32, lens position on the focus 14cm (steps) */
    uint16_t focus_20cm_idx;         /**< READONLY u32, lens position on the focus 20cm (steps) */
    uint16_t focus_30cm_idx;         /**< READONLY u32, lens position on the focus 30cm (steps) */
    uint16_t focus_40cm_idx;         /**< READONLY u32, lens position on the focus 40cm (steps) */
    uint16_t focus_50cm_idx;         /**< READONLY u32, lens position on the focus 50cm (steps) */
    uint16_t focus_60cm_idx;         /**< READONLY u32, lens position on the focus 60m (steps) */
    uint16_t focus_120cm_idx;        /**< READONLY u32, lens position on the focus 120cm (steps) */
    uint16_t inf_limit_idx;          /**< READONLY u32, lens position on the focus infinite (steps) */
} focus_tab_t;

typedef struct _zoom_tab_s {
    uint16_t zoom_idx_x1;        /**< READONLY u32, lens position on the zoom x1(steps) */
    uint16_t zoom_idx_x2;        /**< READONLY u32, lens position on the zoom x2(steps) */
    uint16_t zoom_idx_x3;        /**< READONLY u32, lens position on the zoom x3(steps) */
    uint16_t zoom_idx_x4;        /**< READONLY u32, lens position on the zoom x4(steps) */
    uint16_t zoom_idx_x5;        /**< READONLY u32, lens position on the zoom x5(steps) */
    uint16_t zoom_idx_x6;        /**< READONLY u32, lens position on the zoom x6(steps) */
    uint16_t zoom_idx_x7;        /**< READONLY u32, lens position on the zoom x7(steps) */
    uint16_t zoom_idx_x8;        /**< READONLY u32, lens position on the zoom x8(steps) */
    uint16_t zoom_idx_x9;        /**< READONLY u32, lens position on the zoom x9(steps) */
    uint16_t zoom_idx_x10;        /**< READONLY u32, lens position on the zoom x10(steps) */
    uint16_t zoom_idx_x11;        /**< READONLY u32, lens position on the zoom x11(steps) */
    uint16_t zoom_idx_x12;        /**< READONLY u32, lens position on the zoom x12(steps) */
    uint16_t zoom_idx_x13;        /**< READONLY u32, lens position on the zoom x13(steps) */
    uint16_t zoom_idx_x14;        /**< READONLY u32, lens position on the zoom x14(steps) */
    uint16_t zoom_idx_x15;        /**< READONLY u32, lens position on the zoom x15(steps) */
    uint16_t zoom_idx_x16;        /**< READONLY u32, lens position on the zoom x16(steps) */
    uint16_t zoom_idx_x17;        /**< READONLY u32, lens position on the zoom x17(steps) */
    uint16_t zoom_idx_x18;        /**< READONLY u32, lens position on the zoom x18(steps) */
    uint16_t zoom_idx_x19;        /**< READONLY u32, lens position on the zoom x19(steps) */
    uint16_t zoom_idx_x20;        /**< READONLY u32, lens position on the zoom x20(steps) */
} zoom_tab_t;

typedef struct _iris_tab_s {
    uint16_t full_open_idx;      /**< READONLY u32, iris position on the full open aperture (steps) */
    uint16_t iris_1p4_idx;       /**< READONLY u32, iris position on the aperture diameter 1/1.4 (steps) */
    uint16_t iris_2_idx;         /**< READONLY u32, iris position on the aperture diameter 1/2 (steps) */
    uint16_t iris_2p8_idx;       /**< READONLY u32, iris position on the aperture diameter 1/2.8 (steps) */
    uint16_t iris_4_idx;         /**< READONLY u32, iris position on the aperture diameter 1/4 (steps) */
    uint16_t iris_5p6_idx;       /**< READONLY u32, iris position on the aperture diameter 1/5.6 (steps) */
    uint16_t iris_8_idx;         /**< READONLY u32, iris position on the aperture diameter 1/8 (steps) */
    uint16_t iris_11p3_idx;      /**< READONLY u32, iris position on the aperture diameter 1/11.3 (steps) */
    uint16_t iris_16_idx;        /**< READONLY u32, iris position on the aperture diameter 1/16 (steps) */
    uint16_t iris_22p6_idx;      /**< READONLY u32, iris position on the aperture diameter 1/22.6 (steps) */
    uint16_t iris_32_idx;        /**< READONLY u32, iris position on the aperture diameter 1/32 (steps) */
    uint16_t iris_45p2_idx;      /**< READONLY u32, iris position on the aperture diameter 1/45.2 (steps) */
    uint16_t iris_64_idx;        /**< READONLY u32, iris position on the aperture diameter 1/64 (steps) */
    uint16_t iris_90p5_idx;      /**< READONLY u32, iris position on the aperture diameter 1/90.5 (steps) */
    uint16_t iris_128_idx;       /**< READONLY u32, iris position on the aperture diameter 1/128 (steps) */
    uint16_t close_idx;          /**< READONLY u32, iris position on the close aperture (steps) */
} iris_tab_t;


typedef struct _LENS_PARAM_T {
    MBP_U32 lens_type;                 /**< READONLY u32, lens type which assigns one of the enum type after probing */

    MBP_U32 focus_def_pos;             /**< READONLY u32,  lens default focus position (steps) */
    MBP_U32 zoom_def_pos;              /**< READONLY u32,  lens default zoom position (steps) */
    MBP_U32 iris_def_pos;              /**< READONLY u32,  lens default aperture position (steps) */

    MBP_U32 focus_min_pos;            /**< READONLY u32,  lens focus min steps (steps) */
    MBP_U32 focus_max_pos;            /**< READONLY u32,  lens focus max steps (steps) */

    MBP_U32 fixed_focal_length;        /**< READONLY u32,  fixed focal length of the lens (mm x 10000) */
    MBP_U32 fixed_fno;                 /**< READONLY u32,  fixed aperture numbers under current zoom (F number x 10000) */

    MBP_U32 zoom_is_support;           /**< READONLY u32,  lens support zoom control */
    MBP_U32 zoom_max_ratio;            /**< READONLY u32,  zoom scale ratio (1.0 zoom x 10) */
    MBP_U32 iris_is_support;           /**< READONLY u32,  lens support auto IRIS aperture control */
    MBP_U32 iris_type;                 /**< READONLY u32, 0:DC-iris 1:P-iris */
    MBP_U32 iris_min_effect_aperture;  /**< READONLY u32,  lens min effective aperture diameter (mm x 10000) */
    MBP_U32 iris_max_effect_aperture;  /**< READONLY u32,  lens max effective aperture diameter (mm x 10000) */
    focus_tab_t focus_table;
    zoom_tab_t zoom_table;
    iris_tab_t iris_table;
} LENS_PARAM_T;

typedef struct _CALIB_SENSOR_ATTR {
    char *calibSensorName;
    int32_t calibMode;
} CALIB_SENSOR_ATTR;

/************************** sensor's interface to alg *********************/
typedef struct _ALG_SENSOR_DEFAULT_T
{
    uint32_t fps;                             // Actual sensor fps
    uint32_t pixels_per_line;                 // Actual pixels per line after scaling/binning
    int hcg_fixed_ratio;                 // HCG mode fixed gain ratio
    int again_log2;                      // analog gain value in log2 format
    int again_log2_max;                  // Maximum analog gain value in log2 format
    int again_high_log2;                 // HCG analog gain value in log2 format
    int again_high_log2_max;             // Maximum HCG analog gain value in log2 format
    int dgain_log2;                      // digital gain value in log2 format
    int dgain_log2_max;                  // Maximum digital gain value in log2 format
    int dgain_high_log2;                 // HCG analog gain value in log2 format
    int dgain_high_log2_max;             // Maximum HCG analog gain value in log2 format
    int again_accuracy_fmt;              // Precision of the gain format 0: linear 1: log2
    int again_accuracy;                  // Precision of the gain
    int again_high_accuracy_fmt;         // Precision of the HCG format 0: linear 1: log2
    int again_high_accuracy;             // Precision of the HCG
    int dgain_accuracy_fmt;              // Precision of the digital gain format 0: linear 1: log2
    int dgain_accuracy;                  // Precision of the digital gain
    int dgain_high_accuracy_fmt;         // Precision of the HCG digital gain format 0: linear 1: log2
    int dgain_high_accuracy;             // Precision of the HCG digital gain
    int expos_lines;                     // the exposure time lines
    int expos_accuracy;                  // Precision of the exposure time
    int sexpos_lines;                    // the short exposure time lines
    int sexpos_accuracy;                 // Precision of the short exposure time
    int vsexpos_lines;                   // the very short exposure time lines
    int vsexpos_accuracy;                // Precision of the very short exposure time
    int vvsexpos_lines;                  // the very very short exposure time lines
    int vvsexpos_accuracy;               // Precision of the very very short exposure time
    uint32_t integration_time_min;           // Minimum integration time for the sensor in lines
    uint32_t integration_time_max;           // Maximum integration time for the sensor in lines without dropping fps
    uint32_t integration_time_long_max;      // Maximum integration time for long
    uint32_t integration_time_limit;         // Maximum possible integration time for the sensor
    uint16_t day_light_integration_time_max; // Limit of integration time for non-flickering light source
    uint8_t integration_time_apply_delay;    // Delay to apply integration time in frames
    uint8_t isp_exposure_channel_delay;      // Select which WDR exposure channel gain is delayed 0-none, 1-long, 2-medium, 3-short (only 0 and 1 implemented)
    uint8_t gain_apply_delay;                // Delay to apply gain time in frames
    int xoffset;                        // Used for image stabilization
    int yoffset;                        // Used for image stabilization
    uint32_t lines_per_second;               // Number of lines per second used for antiflicker
    int sensor_exp_number;              // Number of different exposures supported by the sensor
    int sensor_gain_number;             // Number of different gain supported by the sensor
    uint8_t bits;                            // current raw bit
    uint8_t raw_mode;                        // current raw format
    uint8_t pattern;                         // current pattern
    image_resolution_t total;               // Total resolution of the image with blanking
    image_resolution_t active;              // Active resolution without blanking

    uint32_t      u32AGain[4];
    uint32_t      u32DGain[4];
    uint32_t      u32Inttime[2][4];

    uint16_t      u16GainCnt;
    uint16_t      u16IntTimeCnt;
} ALG_SENSOR_DEFAULT_T;

typedef ALG_SENSOR_DEFAULT_T ALG_SENSOR_DEFAULT_S;

typedef struct _ALG_SPEC_SENSOR_DEFAULT_T
{
    MBP_U8 reserved; /* ABI: avoid empty struct under extern "C" */
} ALG_SPEC_SENSOR_DEFAULT_T;

typedef ALG_SPEC_SENSOR_DEFAULT_T ALG_SPEC_SENSOR_DEFAULT_S;

typedef struct _ALG_FSWDR_ATTR_T
{
    ISP_FSWDR_MODE_E enFSWDRMode;
} ALG_FSWDR_ATTR_T;

/*
    NOTICE:ALG_AE_INFO_PRESET_T should sync with RTOS
*/
typedef struct _ALG_AE_INFO_PRESET_T
{
    MBP_U32 ae_converged;           /**< READONLY u1,  ae converged */
    MBP_U32 ae_slight_change;       /**< READONLY u1,  ae slight change */
    MBP_U32 ae_sys_lux;             /**< READONLY u22.10, Light intensity */
    MBP_S32  ae_sys_expos_log2;      /**< READONLY u20.12, current system gain log2 value base on one exposure line */
    MBP_U32 ae_sys_ratio;           /**< READONLY u26.6, ae exposure ratio */
    MBP_U32 ae_sys_min_ratio;       /**< READONLY u26.6, The minimum exposure ratio allowed by the system */
    MBP_U32 ae_sys_expos_full;      /**< READONLY u1, ae exposure time is full */
    /**< AE router output */
    MBP_U32 ae_sns_expos_lines;     /**< READONLY u32, current sensor used exposure lines */
    MBP_U32 ae_sns_sexpos_lines;    /**< READONLY u32, current sensor used short exposure lines */
    MBP_U32 ae_sns_vsexpos_lines;   /**< READONLY u32, current sensor used very short exposure lines */
    MBP_U32 ae_sns_vvsexpos_lines;  /**< READONLY u32, current sensor used very very short exposure lines */
    MBP_S32  ae_sns_expo_log2;       /**< READONLY u32, 20.12 current sensor used log2 of exposure line numbers */
    MBP_S32  ae_sns_shuttime;        /**< READONLY u32, 20.12 current sensor used log2 of exposure time is 20.12 ms */
    MBP_S32  ae_sns_again;           /**< READONLY u32, 20.12 current sensor used log2 of analog gain */
    MBP_S32  ae_sns_hc_again;        /**< READONLY u32, 20.12 current sensor used log2 of analog high conversion gain */
    MBP_S32  ae_sns_dgain;           /**< READONLY u32, 20.12 current sensor used log2 of digital gain */
    MBP_S32  ae_sns_hc_dgain;        /**< READONLY u32, 20.12 current sensor used log2 of digital high conversion gain */
    MBP_S32  ae_isp_gain;            /**< READONLY u32, 20.12 current sensor used log2 of ISP gain */
    MBP_S32  ae_total_gain;          /**< READONLY u32, 20.12 current sensor used log2 of total gain */
    MBP_S32  ae_lowlight_enh_ratio;  /**< READONLY u32, 22.10 low light increase gain multiplier */
    MBP_S32  ae_dn_det_dec;          /**< READONLY u1, 0: day 1:night */
    MBP_U32 ae_flicker_is_limit;    /**< READONLY u1, flicker limit status */
} ALG_AE_INFO_PRESET_T;

/*
    NOTICE:ALG_AWB_INFO_PRESET_T should sync with RTOS
*/
typedef struct _ALG_AWB_INFO_PRESET_T
{
    MBP_U32 awb_converged;          /**< u1, awb converged */
    MBP_U32 awb_sys_r_gain;         /**< u32, current system awb mode red gain */
    MBP_U32 awb_sys_g_gain;         /**< u32, current system awb mode green gain */
    MBP_U32 awb_sys_b_gain;         /**< u32, current system awb mode blue gain */
    MBP_U32 awb_sys_r_gain_uncomp;         /**< u32, current system awb mode red gain */
    MBP_U32 awb_sys_g_gain_uncomp;         /**< u32, current system awb mode green gain */
    MBP_U32 awb_sys_b_gain_uncomp;         /**< u32, current system awb mode blue gain */
    MBP_U32 awb_sys_ct;             /**< u32, current system awb mode color temperature */
    MBP_S32  awb_sys_cdiff;          /**< s32, current system awb mode color difference */
    MBP_U32 awb_gauss_ct;           /**< u32, current system awb mode color temperature for LSC */
    MBP_S32  awb_gauss_cdiff;        /**< s32, current system awb mode color difference for LSC */
    MBP_U32 awb_lns_r_gain;
    MBP_U32 awb_lns_b_gain;
    MBP_S32  awb_crlns_rg;
    MBP_S32  awb_crlns_bg;
} ALG_AWB_INFO_PRESET_T;

typedef struct _ALG_AAA_RTOS_PRESET_T{
    ALG_AE_INFO_PRESET_T ae_info;
    ALG_AWB_INFO_PRESET_T awb_info;
} ALG_AAA_RTOS_PRESET_T;

typedef struct _ALG_SENSOR_EXP_FUNC_T
{
    int (*pfn_cmos_get_alg_default)(int ViPipe, ALG_SENSOR_DEFAULT_S *pstAlgSnsDft);
    int (*pfn_cmos_get_alg_spec_default)(int ViPipe, ALG_SPEC_SENSOR_DEFAULT_S *pstAlgSpecSnsDft);

    /* the function of sensor set fps */
    void(*pfn_cmos_fps_set)(int ViPipe, float f32Fps, ALG_SENSOR_DEFAULT_S *pstAeSnsDft);
    void(*pfn_cmos_slow_framerate_set)(int ViPipe, uint32_t u32FullLines, ALG_SENSOR_DEFAULT_S *pstAeSnsDft);

    /* w_le isp notify ae to update sensor regs, ae call these funcs. */
    void (*pfn_cmos_alg_update)(int ViPipe);

    void (*pfn_cmos_again_calc_table)(int ViPipe, uint32_t *pu32AgainLin, uint32_t *pu32AgainDb);
    void (*pfn_cmos_dgain_calc_table)(int ViPipe, uint32_t *pu32DgainLin, uint32_t *pu32DgainDb);
    void (*pfn_cmos_inttime_calc_table)(int ViPipe, uint32_t pu32ExpL, uint32_t pu32ExpS, uint32_t pu32ExpVS, uint32_t pu32ExpVVS);

    void (*pfn_cmos_get_inttime_max)(VI_PIPE ViPipe, MBP_U16 u16ManRatioEnable, MBP_U32 *au32Ratio, MBP_U32 *au32IntTimeMax, MBP_U32 *au32IntTimeMin, MBP_U32 *pu32LFMaxIntTime);

    /* long frame mode set */
    void(*pfn_cmos_ae_fswdr_attr_set)(VI_PIPE ViPipe, ALG_FSWDR_ATTR_T *pstAeFSWDRAttr);

    /* for download bin file */
    void(*pfn_cmos_get_sensor_attr)(VI_PIPE ViPipe, CALIB_SENSOR_ATTR *pstSensorAttr);

    /*for linux read rtos preset*/
    MBP_S32(*pfn_cmos_get_rtos_preset)(VI_PIPE ViPipe, ALG_AAA_RTOS_PRESET_T *preset_ptr_in);

    /* core work mode*/
    MBP_S32(*pfn_cmos_get_core_work_mode)(VI_PIPE ViPipe);
} ALG_SENSOR_EXP_FUNC_T;

typedef ALG_SENSOR_EXP_FUNC_T ALG_SENSOR_EXP_FUNC_S;

typedef struct _ALG_LENS_FUNC_T
{
    void( *pfn_focus_move )( uint32_t ctx, uint16_t position );
    uint8_t ( *pfn_focus_is_moving )( uint32_t ctx );
    uint16_t ( *pfn_focus_get_pos )( uint32_t ctx );
    const LENS_PARAM_T *( *pfn_lens_get_parameters )( uint32_t ctx );
    void( *pfn_zoom_move )( uint16_t ctx, uint16_t next_zoom );
    uint8_t ( *pfn_zoom_is_moving )( uint32_t ctx );
    uint16_t ( *pfn_zoom_get_pos )( uint32_t ctx );
    void ( *pfn_iris_move )( uint32_t ctx, uint16_t position );
    uint8_t ( *pfn_iris_is_moving )( uint32_t ctx );
    uint16_t ( *pfn_iris_get_pos )( uint32_t ctx );
} ALG_LENS_FUNC_T;

typedef ALG_LENS_FUNC_T ALG_LENS_FUNC_S;

typedef struct _ALG_AE_FUNC_T
{
    MBP_S32 (*pfn_ae_core_algo)(void* hand, const void *stats, const void *aaa_reg, const void *ref, void *res);
    MBP_S32 (*pfn_ae_rout_algo)(void* hand, const void *stats,const void *aaa_reg, const void *ref, void *res);
} ALG_AE_FUNC_T;

typedef ALG_AE_FUNC_T ALG_AE_FUNC_S;

typedef struct _ALG_AWB_FUNC_T
{
    MBP_S32 (*pfn_awb_core_algo)(void* hand, const void *stats, void *aaa_reg, const void *ref, void *res);
} ALG_AWB_FUNC_T;

typedef ALG_AWB_FUNC_T ALG_AWB_FUNC_S;

typedef struct _ALG_SENSOR_REGISTER_T
{
    ALG_SENSOR_EXP_FUNC_S stSnsExp;
} ALG_SENSOR_REGISTER_T;

typedef struct _ALG_LENS_REGISTER_T
{
    ALG_LENS_FUNC_S stLensFunc;
} ALG_LENS_REGISTER_T;

typedef struct _ALG_AE_REGISTER_T
{
    ALG_AE_FUNC_S stAeFunc;
} ALG_AE_REGISTER_T;

typedef struct _ALG_AWB_REGISTER_T
{
    ALG_AWB_FUNC_S stAwbFunc;
} ALG_AWB_REGISTER_T;

typedef enum  {
	ISP_RAW2DDR_MODE,
	ISP_ALLSCAN_MODE,
	ISP_SCANTILE_MODE,
	ISP_ALLTILE_MODE,
	ISP_OFFTILE_MODE,
	ISP_WORK_MODE_MAX
} ISP_WORK_MODE;

typedef struct _AML_ALG_CTX_S
{
    /* usr var */
    //MBP_U16                  u16DetectTemp;
    //MBP_U8                   u8WbType;

    /* communicate with isp */
    //ISP_ALG_PARAM_T          stAlgParam;
    //MBP_U32                  u32FrameCnt;
    //ISP_ALG_INFO_T           stAlgInfo;
    //ISP_ALG_RESULT_T         stAlgResult;
    //VI_PIPE                  IspBindDev;

    /* communicate with sensor, defined by user. */
    MBP_BOOL_E                 bSnsRegister;
    //SENSOR_ID                SensorId;
    //ISP_SNS_ATTR_INFO_T      stSnsAttrInfo;
    ALG_SENSOR_DEFAULT_S       stSnsDft;
    ALG_SENSOR_REGISTER_T      stSnsRegister;

    MBP_BOOL_E                 bLensRegister;
    ALG_LENS_REGISTER_T        stLensRegister;
    CALIB_SENSOR_ATTR stSensorAttr;//sensor name;work mode: hdr or wdr

    MBP_BOOL_E                 bAeRegister;
    ALG_AE_REGISTER_T          stAeRegister;

    MBP_BOOL_E                 bAwbRegister;
    ALG_AWB_REGISTER_T         stAwbRegister;
    /* global variables of alg algorithm */
} AML_ALG_CTX_S;

#define LOG2_GAIN_SHIFT 12
#define SHUTTER_TIME_SHIFT 12

void aisp_enable(uint32_t ctx_id, AML_ALG_CTX_S *pstAlgCtx, void *calib);
void aisp_disable(uint32_t ctx_id);
void aisp_alg2user(uint32_t ctx_id, void *param);
void aisp_alg2kernel(uint32_t ctx_id, void *param);

/** @brief read raw data form memory and normalize raw data
 *
 * @param pVin      Raw data bit stream
 * @param pData     Output normalize raw data value
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param endian    raw data endian format
 * @param src_bit_depth raw data source bit depth
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_read_raw_data(unsigned char *pVin, int *pData, int xsize, int ysize, int endian, int src_bit_depth);

/** @brief optical center point calibration
 *
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param phase_ofst    phase offset of raw color components
 * @param pData     normalize raw data
 * @param pLSC      calibration data of the radial shading.
 * @param pVout     raw data after radial shading correction.
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_optical_center_point_calibration(int xsize, int ysize, int *phase_ofst, int *pData, int *center_x, int *center_y);

/** @brief radial shading calibrate and output radial shading correcte table.
 *
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param phase_ofst    phase offset of raw color components
 * @param pData     normalize raw data
 * @param chroma_s  radial shading chroma correction strength percentage
 * @param luma_s    radial shading luma correction strength percentage
 * @param mesh_s    normalize value of the radial shading calibration value
 * @return error code
 *   @retval 0  - success
 */

int aml_radial_shading_calibration(int xsize, int ysize, int *phase_ofst, int center_ofs_x, int center_ofs_y, int *pData, int chroma_s, int luma_s, int *pVout);

/** @brief radial shading correct process
 *
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param phase_ofst    phase offset of raw color components
 * @param pData     normalize raw data
 * @param pLSC      calibration data of the radial shading.
 * @param pVout     raw data after radial shading correction.
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_radial_shading_correct(int xsize, int ysize, int *phase_ofst, int center_ofs_x, int center_ofs_y, int *pData, int *pRadLSC, int *pVout);

/** @brief mesh shading calibrate and output mesh shading correcte table.
 *
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param X_node    horizontal nodes of the mesh shading table
 * @param Y_node    vertical nodes of the mesh shading table
 * @param phase_ofst    phase offset of raw color components
 * @param pData     normalize raw data
 * @param chroma_s  mesh shading chroma correction strength percentage
 * @param luma_s    mesh shading luma correction strength percentage
 * @param mesh_s    normalize value of the mesh shading calibration value
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 *   @retval -2 - mesh scale parameter error
 */
int aml_mesh_shading_calibration(int xsize, int ysize, int X_node, int Y_node, int *phase_ofst, int *pData, int chroma_s, int luma_s, int mesh_s, int *pVout);

/** @brief mesh shading correct process
 *
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param X_node    horizontal nodes of the mesh shading table
 * @param Y_node    vertical nodes of the mesh shading table
 * @param phase_ofst    phase offset of raw color components
 * @param pData     normalize raw data
 * @param pLSC      calibration data of the mesh shading.
 * @param meshscale normalize value of the mesh shading calibration value
 * @param pVout     raw data after mesh shading correction.
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_mesh_shading_correct(int xsize, int ysize, int X_node, int Y_node, int *phase_ofst, int *pData, int *pLSC, int meshscale, int *pVout);


/** @brief mesh shading calibration data compression processing
 *
 * @param X_node    horizontal nodes of the mesh shading table
 * @param Y_node    vertical nodes of the mesh shading table
 * @param pLSC      calibration data of the mesh shading.
 * @param pLSC_enc  calibration data after compression.
 * @param size      max size of the compression buffer
 * @param lose_level compression lose level, 0:lossless
 * @return          valid compression byte numbers
 */
int aml_mesh_shading_compress(int X_node, int Y_node, int *pLSC, unsigned char *pLSC_enc, int size, int lose_level);

/** @brief mesh shading calibration data decompression processing
 *
 * @param X_node    horizontal nodes of the mesh shading table
 * @param Y_node    vertical nodes of the mesh shading table
 * @param pLSC      calibration data of the mesh shading.
 * @param pLSC_enc  calibration data after compression.
 * @param size      max size of the compression buffer
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_mesh_shading_decompress(int X_node, int Y_node, int *pLSC, unsigned char *pLSC_enc, int size);

/** @brief radial shading calibration data compression processing
 *
 * @param node     nodes of the mesh shading table
 * @param pLSC      calibration data of the mesh shading.
 * @param pLSC_enc  calibration data after compression.
 * @param size      max size of the compression buffer
 * @param lose_level compression lose level, 0:lossless
 * @return          valid compression byte numbers
 */
int aml_rad_shading_compress(int node, int *pLSC, unsigned char *pLSC_enc, int size, int lose_level);

/** @brief radial shading calibration data decompression processing
 *
 * @param node      nodes of the mesh shading table
 * @param pLSC      calibration data of the mesh shading.
 * @param pLSC_enc  calibration data after compression.
 * @param size      max size of the compression buffer
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_rad_shading_decompress(int node, int *pLSC, unsigned char *pLSC_enc, int size);

/** @brief white balance OTP calibration processing
 *
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param pData     normalize raw data
 * @param pVout     white balance OTP data.
 * @param phase_ofst    phase offset of raw color components
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_white_balance_otp_calibration(int xsize, int ysize, int *pData, int *pVout, int *phase_ofst);

/** @brief black level correct process
 *
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param phase_ofst    phase offset of raw color components
 * @param blc       black level value
 * @param pVout     raw data after mesh shading correction.
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_black_level_correct(int xsize, int ysize, int *phase_ofst, int *blc, int *pVout);

/** @brief  white balance correct process
 *
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param in_bw     white balance OTP data.
 * @param phase_ofst    phase offset of raw color components
 * @param pVout     raw data after mesh shading correction.
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_white_balance_correct(int xsize, int ysize, int *in_bw, int *phase_ofst, int *pVout);

/** @brief Convert Raw data format to RGB data format
 *
 * @param xsize     width of the raw data resolution
 * @param ysize     height of the raw data resolution
 * @param phase_ofst    phase offset of raw color components
 * @param pData     normalize raw data
 * @param pVout     RGB data
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_demosaic(int xsize, int ysize, int *phase_ofst, int *pData, int *pVout);
/** @brief write RGB data into file, use BMP file format
 *
 * @param filename  BMP file name
 * @param cpBufr    RGB data stream
 * @param xsize     width of the RGB data resolution
 * @param ysize     height of the RGB data resolution
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
int aml_write_bmp(char *filename, int *cpBufr, int xsize, int ysize);
/** @brief whether print debug info.
 *
 * @param debug     0:disable 1: enable
 * @return error code
 *   @retval 0  - success
 *   @retval -1 - failure
 */
void aml_debug_mode_set(int debug);

void rad_129_to_49(uint16_t *rad129, uint16_t* rad49);
void mesh_32x32_to_16x16(uint8_t *mesh16x16, uint8_t* mesh32x32, int noeq, int norm);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif
