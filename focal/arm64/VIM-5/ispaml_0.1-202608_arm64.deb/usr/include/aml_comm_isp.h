/*
 * Copyright (C) 2019-2024 Amlogic, Inc. All rights reserved.
 *
 * All information contained herein is Amlogic confidential.
 *
 * T_s software is provided to you pursuant to Software License Agreement
 * (SLA) with Amlogic Inc ("Amlogic"). T_s software may be used
 * only in accordance with the terms of t_s agreement.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification is strictly prohbited without prior written permission from
 * Amlogic.
 *
 * TMBPS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF TMBPS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __AML_COMM_ISP_H__
#define __AML_COMM_ISP_H__

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/************** added for isp5-a9 ************************************/

typedef uint64_t MBP_U64;
typedef uint32_t MBP_U32;
typedef uint16_t MBP_U16;
typedef uint8_t  MBP_U8;

typedef int64_t MBP_S64;
typedef int32_t MBP_S32;
typedef int16_t MBP_S16;
typedef int8_t  MBP_S8;

typedef void    MBP_VOID;
typedef float   MBP_FLOAT;

typedef int32_t VI_PIPE;

#define MBP_NULL  NULL

typedef enum mbp_bool_e{
    MBP_FALSE = 0,
    MBP_TRUE = 1,
} MBP_BOOL_E;

/********************** amlogic private ***********************************/

#define ISP_MAX_CHN_NUM               (6)

/****************************************************************************
 * MACRO DEFINITION                                                         *
 ****************************************************************************/

//#define RES_WIDTH_MAX(dev)              (g_au16ResWMax[dev])
#define RES_WIDTH_MIN                   (120)
//#define RES_HEIGHT_MAX(dev)             (g_au16ResHMax[dev])
#define RES_HEIGHT_MIN                  (120)
#define FRAME_RATE_MAX                  (65535.0)

#define VREG_MAX_NUM                    (16)
#define MBPST_THRESH_NUM                (4)

#define AWB_ZONE_ORIG_ROW               (32)
#define AWB_ZONE_ORIG_COLUMN            (24)
#define AE_ZONE_ROW                     (15)
#define AE_ZONE_COLUMN                  (17)
#define MG_ZONE_ROW                     (15)
#define ISP_DO_NOT_NEED_SWITCH_IMAGEMODE (-2)

#define MG_ZONE_COLUMN                  (17)
#define AWB_ZONE_NUM                    (AWB_ZONE_ORIG_ROW * AWB_ZONE_ORIG_COLUMN)
#define AWB_ZONE_STITCH_MAX             (AWB_ZONE_NUM * ISP_MAX_STITCH_NUM)
#define AF_ZONE_ROW                     (15)
#define AF_ZONE_COLUMN                  (17)
#define LIGHTSOURCE_NUM                 (4)
//#define MAX_AWB_LIB_NUM                 (AWB_LIB_NUM)
//#define MAX_AE_LIB_NUM                  (AE_LIB_NUM)
//#define MAX_ALG_LIB_NUM                  (ALG_LIB_NUM)

#define AE_MIN_WIDTH                    (256)
#define AE_MIN_HEIGHT                   (120)
#define AWB_MIN_WIDTH                   (60)
#define AWB_MIN_HEIGHT                  (14)

#define GAMMA_NODE_NUM                  (129)
#define PREGAMMA_NODE_NUM               (129)
#define PREGAMMA_SEG_NUM                (8)

#define LCAC_STRENGTH_NUM               (16)

#define ISP_AUTO_ISO_STRENGTH_NUM       (10)
#define ISP_SHARPEN_LUMA_NUM            (32)
#define ISP_SHARPEN_GAIN_NUM            (32)

#define ISP_MAX_SNS_REGS                (32)

#define MBP_ISP_RLSC_POINTS                (129)
#define MBP_ISP_RLSC_DEFAULT_RADIAL_STR    (4096)
#define MBP_ISP_RLSC_DEFAULT_SCALE         (3)
#define MBP_ISP_RLSC_DEFAULT_MANUAL_WEIGHT (256)
#define MBP_ISP_RLSC_DEFAULT_WBGAIN        (256)
#define MBP_ISP_RLSC_DEFAULT_LIGHT         (0)
#define MBP_ISP_RLSC_WEIGHT_Q_BITS         (8)

#define ISP_VREG_SIZE_BIN               (0x20000)
#define ALG_LIB_VREG_SIZE_BIN           (0x1000)
#define WDR_MAX_FRAME_NUM               (4)

#define BAYER_CALIBTAION_MAX_NUM        (50)
#define MBP_ISP_BAYERNR_STRENGTH_DIVISOR (100)
#define MBP_ISP_BAYERNR_CORINGLOW_STRENGTH_DIVISOR (10000)
#define AI_MAX_STEP_FNO_NUM             (1024)

#define ISP_BAS_TAPS_ROW_NUM            (17)
#define ISP_BAS_TAPS_COL_6              (6)
#define ISP_BAS_TAPS_COL_4              (4)
#define MBP_ISP_BAYERNR_LUT_LENGTH       (33)
#define MBP_ISP_BAYERNR_LMTLUTNUM        (129)
#define PRO_MAX_FRAME_NUM               (8)

#define MBP_ISP_DEMOSAIC_LUT_LENGTH      (17)
#define ISP_BAYER_CHN_NUM               (4)

#define LDCI_LPF_LUT_SIZE               (9)
#define LDCI_HE_LUT_SIZE                (33)
#define LDCI_DE_USM_LUT_SIZE            (33)
#define LDCI_COLOR_GAIN_LUT_SIZE        (65)

#define NoiseSet_EleNum                 (7)
#define CCM_MATRIX_SIZE                 (12)
#define CCM_MATRIX_NUM                  (201)
#define CCM_ADJ_SIZE                    (10)

#define MBP_ISP_DRC_CUBIC_POINT_NUM      (5)
#define MBP_ISP_DRC_CC_NODE_NUM          (33)
#define MBP_ISP_DRC_TM_NODE_NUM          (200)
#define MBP_ISP_DRC_TM_SEG_NUM           (8)
#define MBP_ISP_DRC_EXP_COMP_SAMPLE_NUM  (8)
#define MBP_ISP_DRC_SHP_LOG_CONFIG_NUM   (16)

#define LOG_LUT_SIZE                    (1025)
#define PRE_LOG_LUT_SIZE                (1025)

#define MBP_ISP_DE_LUMA_GAIN_LUT_N       (17)
#define ISP_EXP_RATIO_STRENGTH_NUM      (16)

/****************************************************************************
 * GENERAL STRUCTURES                                                       *
 ****************************************************************************/
/*
ISP Error Code
0x40 = ISP_NOT_INIT
0x41 = ISP_MEM_NOT_INIT
0x42 = ISP_ATTR_NOT_CFG
0x43 = ISP_SNS_UNREGISTER
0x44 = ISP_INVALID_ADDR
0x45 = ISP_NOMEM
0x46 = ISP_NO_INT
*/

#pragma pack(1)
typedef struct _ISP_INIT_ATTR_T
{
    MBP_U32 u32ExpTime;
    MBP_U32 u32AGain;
    MBP_U32 u32DGain;
    MBP_U32 u32ISPDGain;
    MBP_U32 u32Exposure;
    MBP_U32 u32LinesPer500ms;
    MBP_U32 u32PirisFNO;
    MBP_U16 u16WBRgain;
    MBP_U16 u16WBGgain;
    MBP_U16 u16WBBgain;
    MBP_U16 u16SampleRgain;
    MBP_U16 u16SampleBgain;
} ISP_INIT_ATTR_T ;

typedef enum _ISP_ERR_CODE_E
{
    ERR_ISP_NOT_INIT= 0x40,       //ISP not init
    ERR_ISP_MEM_NOT_INIT,         //ISP memory not init
    ERR_ISP_OPEN_DEV,             //ISP failed to open the dev
    ERR_ISP_OPEN_CHN,             //ISP failed to open the chn
    ERR_ISP_ATTR_NOT_CFG,         //ISP attribute not cfg
    ERR_ISP_SNS_REGISTER,         //ISP sensor register
    ERR_ISP_SNS_UNREGISTER,       //ISP sensor unregister
    ERR_ISP_INVALID_ADDR,         //ISP invalid address
    ERR_ISP_NOMEM,                //ISP nomem
    ERR_ISP_NULL_POINTER,         //ISP null pointer
    ERR_ISP_ALG_REGISTER,         //ISP sensor alg register
    ERR_ISP_ALG_UNREGISTER,       //ISP sensor alg unregister
    ERR_ISP_AWB_REGISTER,         //ISP sensor awb register
    ERR_ISP_AWB_UNREGISTER,       //ISP sensor awb unregister
    ERR_ISP_AE_REGISTER,          //ISP sensor ae register
    ERR_ISP_AE_UNREGISTER,        //ISP sensor ae unregister
} ISP_ERR_CODE_E;

typedef enum _ISP_CALIB_MODE_E{
    ISP_CALIB_SDR_NIGHT = 0,
    ISP_CALIB_SDR_DAY = 1,
    ISP_CALIB_WDR_NIGHT = 2,
    ISP_CALIB_WDR_DAY = 3,
    ISP_CALIB_MODE_MAX
} ISP_CALIB_MODE_E;

/*
Defines the working mode of ISP
0 = automatic mode
1 = manual mode
*/
typedef enum _ISP_OP_TYPE_E
{
    OP_TYPE_AUTO    = 0,
    OP_TYPE_MANUAL  = 1,
    OP_TYPE_LUT     = 2,
    OP_TYPE_BUTT
} ISP_OP_TYPE_E;

/*
Defines the ISP correction or detection status
0 = initial status, no calibration
1 = The static defect pixel calibration ends normally
2 = The static defect pixel calibration ends due to timeout.
*/
typedef enum _ISP_STATE_E
{
    ISP_STATE_INIT     = 0,
    ISP_STATE_SUCCESS  = 1,
    ISP_STATE_TIMEOUT  = 2,
    ISP_STATE_BUTT
} ISP_STATUS_E;

/*Defines the bitwidth of the input Bayer image, used for lsc online calibration*/
typedef enum _ISP_BAYER_RAWBIT_E
{
    BAYER_RAWBIT_8BIT    = 8,
    BAYER_RAWBIT_10BIT   = 10,
    BAYER_RAWBIT_12BIT   = 12,
    BAYER_RAWBIT_14BIT   = 14,
    BAYER_RAWBIT_16BIT   = 16,
    BAYER_RAWBIT_BUTT

} ISP_BAYER_RAWBIT_E;

/*
Defines the ISP firmware status
0 = Running status
1 = Frozen status
*/
typedef enum _ISP_FMW_STATE_E
{
    ISP_FMW_STATE_RUN = 0,
    ISP_FMW_STATE_FREEZE,
    ISP_FMW_STATE_BUTT
} ISP_FMW_STATE_E;

/*Defines the WDR mode of the ISP*/
//typedef struct _ISP_WDR_MODE_T
//{
//    MBP_WDR_MODE_E  enWDRMode;
//} ISP_WDR_MODE_T;

typedef union _ISP_MODULE_CTRL_U
{
    MBP_U64  u64Key;
    struct
    {
        MBP_U64  u64bitSrcInpChn    : 2 ;
        MBP_U64  u64bitWdrEn        : 1 ;
        MBP_U64  u64bitWdrInpChn    : 2 ;
        MBP_U64  u64bitDecmpEn      : 1 ;
        MBP_U64  u64bitIfmtEn       : 1 ;
        MBP_U64  u64bitBacEn        : 1 ;
        MBP_U64  u64bitFpnrEn       : 1 ;
        MBP_U64  u64bitGeEn         : 1 ;
        MBP_U64  u64bitDpcEn        : 1 ;
        MBP_U64  u64bitPatEn        : 1 ;
        MBP_U64  u64bitOgEn         : 1 ;
        MBP_U64  u64bitSqrtEotfEn   : 1 ;
        MBP_U64  u64bitLcgeEn       : 1 ;
        MBP_U64  u64bitPdpcEn       : 1 ;
        MBP_U64  u64bitCacEn        : 1 ;
        MBP_U64  u64bitRawcnrEn     : 2 ;
        MBP_U64  u64bitSnr1En       : 1 ;
        MBP_U64  u64bitMcTnrEn      : 1 ;
        MBP_U64  u64bitTnr0En       : 1 ;
        MBP_U64  u64bitCubicCsEn    : 1 ;
        MBP_U64  u64bitLtmEn        : 1 ;
        MBP_U64  u64bitGtmEn        : 1 ;
        MBP_U64  u64bitLnsMeshEn    : 1 ;
        MBP_U64  u64bitLnsRadEn     : 1 ;
        MBP_U64  u64bitWbEn         : 1 ;
        MBP_U64  u64bitBlcEn        : 1 ;
        MBP_U64  u64bitNrEn         : 1 ;
        MBP_U64  u64bitPkEn         : 1 ;
        MBP_U64  u64bitDnlpEn       : 1 ;
        MBP_U64  u64bitDhzEn        : 1 ;
        MBP_U64  u64bitLcEn         : 1 ;
        MBP_U64  u64bitBscEn        : 1 ;
        MBP_U64  u64bitCnr2En       : 1 ;
        MBP_U64  u64bitGammaEn      : 1 ;
        MBP_U64  u64bitCcmEn        : 1 ;
        MBP_U64  u64bitDmscEn       : 1 ;
        MBP_U64  u64bitCscEn        : 1 ;
        MBP_U64  u64bitPtnrEn       : 1 ;
        MBP_U64  u64bitAmcmEn       : 1 ;
        MBP_U64  u64bitFlkrStatEn  : 1 ;
        MBP_U64  u64bitFlkrStatSw  : 2 ;
        MBP_U64  u64bitAwbStatEn   : 1 ;
        MBP_U64  u64bitAwbStatSw   : 3 ;
        MBP_U64  u64bitAeStatEn    : 1 ;
        MBP_U64  u64bitAeStatSw    : 2 ;
        MBP_U64  u64bitAfStatEn    : 1 ;
        MBP_U64  u64bitAfStatSw    : 2 ;
        MBP_U64  u64bitWdrStatEn   : 1 ;
        MBP_U64  u64bitDbgPathEn   : 1 ;
        MBP_U64  u64bitDbgDataSel  : 1 ;
        MBP_U64  u64bitRsv         : 6; /* H  ; [58:63] */
    };
} ISP_MODULE_CTRL_U;

typedef struct _ISP_WDR_FS_AUTO_ATTR_T {
    MBP_S32 s32WdrMotiondectEn;
    MBP_S32 s32WdrMdetcWithblcMode;
    MBP_S32 s32WdrMdetcChksatMode;
    MBP_S32 s32WdrMdetcMotionmapMode;
    MBP_S32 s32WdrMdeciChkstillMode;
    MBP_S32 s32WdrMdeciAddlong;
    MBP_S32 s32WdrMdeciStillThd;
    MBP_S32 s32WdrForcelongEn;
    MBP_S32 s32WdrForcelongThdmode;
    MBP_S32 s32WdrExpcombMaxavgMode;
    MBP_S32 s32WdrExpcombMaxavgRatio;
    MBP_S32 s32WdrStatFltEn;
    MBP_S32 s32WdrMdetcLoWeightOffset[3];
    MBP_S32 s32WdrMdetcHiWeightOffset[3];
    MBP_S32 s32WdrAutoEn;
    MBP_S32 s32WdrMdetcSatThdMode;
    MBP_S32 s32WdrMdetcWeightMode;
    MBP_S32 s32WdrMdetcSatGrOffset;
    MBP_S32 s32WdrMdetcSatGbOffset;
    MBP_S32 s32WdrMdetcSatRgOffset;
    MBP_S32 s32WdrMdetcSatBgOffset;
    MBP_S32 s32WdrMdetcSatIrOffset;
    MBP_S32 s32WdrFlong1Mode;
    MBP_S32 s32WdrDayThd;
    MBP_S32 s32WdrNightThd;
    MBP_S32 s32WdrFlong2DayLothd;
    MBP_S32 s32WdrFlong2DayHithd;
    MBP_S32 s32WdrFlong2NightLothd;
    MBP_S32 s32WdrFlong2NightHithd;
    MBP_S32 s32WdrForceExpEn;
    MBP_S32 s32WdrForceExpMode;
} ISP_WDR_FS_AUTO_ATTR_T;

#define EXPO_MAX_CHANNEL  (2)
typedef struct _ISP_WDR_FS_MANUAL_ATTR_T {
    MBP_S32 s32SatGrThd;
    MBP_S32 s32SatGbThd;
    MBP_S32 s32SatRgThd;
    MBP_S32 s32SatBgThd;
    MBP_S32 s32SatIrThd;
    MBP_S32 s32WdrMdetcLoWeight[EXPO_MAX_CHANNEL];
    MBP_S32 s32WdrMdetcHiWeight[EXPO_MAX_CHANNEL];
    MBP_S32 s32SqrtAgainG;
    MBP_S32 s32SqrtAgainRg;
    MBP_S32 s32SqrtAgainBg;
    MBP_S32 s32SqrtAgainIr;
    MBP_S32 s32SqrtDgainG;
    MBP_S32 s32SqrtDgainRg;
    MBP_S32 s32SqrtDgainBg;
    MBP_S32 s32SqrtDgainIr;
    MBP_S32 s32WdrMdetcTotNoiseflrG[EXPO_MAX_CHANNEL];
    MBP_S32 s32WdrMdetcTotNoiseflrRg[EXPO_MAX_CHANNEL];
    MBP_S32 s32WdrMdetcTotNoiseflrBg[EXPO_MAX_CHANNEL];
    MBP_S32 s32MdeciSexpstillGrLsthd[EXPO_MAX_CHANNEL];
    MBP_S32 s32MdeciSexpstillGbLsthd[EXPO_MAX_CHANNEL];
    MBP_S32 s32MdeciSexpstillRgLsthd[EXPO_MAX_CHANNEL];
    MBP_S32 s32MdeciSexpstillBgLsthd[EXPO_MAX_CHANNEL];
    MBP_S32 s32Flong2Thd0[EXPO_MAX_CHANNEL];
    MBP_S32 s32Flong2Thd1[EXPO_MAX_CHANNEL];
    MBP_S32 s32WdrFlong1Thd0;
    MBP_S32 s32WdrFlong1Thd1;
} ISP_WDR_FS_MANUAL_ATTR_T;

typedef struct _ISP_WDR_FS_ATTR_T
{
    ISP_OP_TYPE_E             enOpType;
    ISP_WDR_FS_MANUAL_ATTR_T  stManual;
    ISP_WDR_FS_AUTO_ATTR_T    stAuto;
} ISP_WDR_FS_ATTR_T;

#define LTM_HIST_BLK (79)
typedef struct _ISP_DRC_CTL_ATTR_T
{
    MBP_S32 s32LtmAutoEn;
    MBP_S32 s32LtmDamper64;
    MBP_S32 s32LtmLminAlpha;
    MBP_S32 s32LtmLmaxAlpha;
    MBP_S32 s32LtmHiGmU7;
    MBP_S32 s32LtmLoGmU6;
    MBP_S32 s32LtmDtlEhnEn;
    MBP_S32 s32LtmVsGtmAlpha;
    MBP_S32 s32LtmCcEn;
    MBP_S32 s32LtmLminMedEn;
    MBP_S32 s32LtmLmaxMedEn;
    MBP_S32 s32LtmBldLvlAdpEn;
    MBP_S32 s32LtmLoHiGmAuto;
    MBP_S32 s32LtmLumaAlpha;
} ISP_DRC_AUTO_ATTR_T;

#define DRC_STA_BLK_REG_NUM  (96)
typedef struct _ISP_DRC_MANUAL_ATTR_T {
    MBP_S32 s32DarkNoise;
    MBP_S32 s32LrU28;
    MBP_S32 s32LminBlk[DRC_STA_BLK_REG_NUM];
    MBP_S32 s32LmaxBlk[DRC_STA_BLK_REG_NUM];
    MBP_S32 s32ExpblendThd0U14;
    MBP_S32 s32ExpblendThd1U14;
    MBP_S32 s32LtmLgm;
    MBP_S32 s32LtmHgm;
    MBP_S32 s32LtmLoHiGmAuto;
    MBP_S32 s32LtmPowYU20;
    MBP_U32 s32TmpRegLtmPowDivisor;
} ISP_DRC_MANUAL_ATTR_T;

typedef struct _ISP_DRC_GAMMA_LUT {
    MBP_S32 s32LtmLoGm;
    MBP_S32 s32LtmHiGm;
} ISP_DRC_GAMMA_LUT;

typedef struct _ISP_DRC_HIST_ATTR_T
{
    MBP_U32 s32HistBlk65[LTM_HIST_BLK];
} ISP_DRC_HIST_ATTR_T;

typedef struct _ISP_DRC_ATTR_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_DRC_MANUAL_ATTR_T stDrcManual;
    ISP_DRC_AUTO_ATTR_T stDrcAuto;
    ISP_DRC_HIST_ATTR_T stHistAttr;
} ISP_DRC_ATTR_T;

typedef struct _ISP_DRC_GAMMA_AUTO_ATTR_T {
    ISP_DRC_GAMMA_LUT astLoHiGm[ISP_AUTO_ISO_STRENGTH_NUM];
} ISP_DRC_GAMMA_AUTO_ATTR_T;

typedef struct _ISP_DRC_GAMMA_MANUAL_ATTR_T {
    MBP_U32 u32LoGammaStr;
    MBP_U32 u32HoGammaStr;
} ISP_DRC_GAMMA_MANUAL_ATTR_T;

typedef struct _ISP_DRC_GAMMA_ATTR_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_DRC_GAMMA_MANUAL_ATTR_T stDrcManual;
    ISP_DRC_GAMMA_AUTO_ATTR_T   stDrcAuto;
} ISP_DRC_GAMMA_ATTR_T;

#define LDCI_SATUR_LUT_NODE         (63)
typedef struct _ISP_LDCI_CTL_ATTR_T
{
    MBP_S32 s32BlkblendMode;
    MBP_S32 s32LmtratMinmax;
    MBP_S32 s32ContrastLow;
    MBP_S32 s32ContrastHig;
    MBP_S32 s32CCcEn;
    MBP_S32 s32YpkbvSlopeLmt1;
    MBP_S32 s32YpkbvSlopeLmt0;
    MBP_S32 s32StrFixed;
    MBP_U32 u32Damper64;
    MBP_S32 s32NodesAlpha;
} ISP_LDCI_CTL_ATTR_T;

typedef struct _ISP_LDCI_STRENGTH_ATTR_T
{
    MBP_S32 s32Lmt0;
    MBP_S32 s32Lmt1;
} ISP_LDCI_STRENGTH_ATTR_T;

typedef struct _ISP_LDCI_AUTO_ATTR_T
{
    ISP_LDCI_CTL_ATTR_T ldci_ctl;
    ISP_LDCI_STRENGTH_ATTR_T ldci_strength;
} ISP_LDCI_AUTO_ATTR_T;

typedef struct _ISP_LDCI_MANUAL_ATTR_T
{
    MBP_S32 s32CurveNodes[96*6];
    MBP_U32 u32HistvldThrd;
    MBP_U32 u32BlackbarMuteThrd;
    MBP_U32 u32PkVld;
    MBP_U32 u32PkNoTrdMrgn;
    MBP_U32 u32PkLstbTh;
    MBP_U32 u32StrFixed;
} ISP_LDCI_MANUAL_ATTR_T;

typedef struct _ISP_LDCI_ATTR_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_LDCI_MANUAL_ATTR_T stManual;
    ISP_LDCI_AUTO_ATTR_T   stAuto;
} ISP_LDCI_ATTR_T;

typedef struct _ISP_LDCI_LUT_ATTR_T
{
    MBP_U16 u16SaturLut[LDCI_SATUR_LUT_NODE];
} ISP_LDCI_LUT_ATTR_T;

typedef struct _ISP_DNLP_AUTO_ATTR_T
{
    MBP_U32 u32DnlpCuvbldMin;
    MBP_U32 u32DnlpCuvbldMax;
    MBP_U32 u32DnlpClashBgn;
    MBP_U32 u32DnlpClashEnd;
    MBP_U32 u32DnlpBlkextOfst;
    MBP_U32 u32DnlpWhtextOfst;
    MBP_U32 u32DnlpBlkextRate;
    MBP_U32 u32DnlpWhtextRate;
    MBP_U32 u32DnlpDbgMap;
    MBP_U32 u32DnlpFinalGain;
    MBP_U32 u32DnlpScurvLowTh;
    MBP_U32 u32DnlpScurvMid1Th;
    MBP_U32 u32DnlpScurvMid2Th;
    MBP_U32 u32DnlpScurvHgh1Th;
    MBP_U32 u32DnlpScurvHgh2Th;
    MBP_U32 u32DnlpMtdrateAdpEn;
    MBP_U32 u32DnlpBleEn;
    MBP_U32 u32DnlpScnChgTh;
    MBP_U32 u32DnlpMtdbldRate;
    MBP_U32 u32DnlpStrFixed;
    MBP_S32 s32DnlpByIsoLuma;
    MBP_S32 s32DnlpScurvGainMode;
    MBP_S32 s32DnlpLumaDbg;
} ISP_DNLP_AUTO_ATTR_T;

typedef struct _ISP_DNLP_MANUAL_ATTR_T
{
    MBP_U32 s32DnlpSchg;
    MBP_U32 s32DnlpBldLvl;
    MBP_U32 s32AlvlGain;
    MBP_U32 s32AlvlOfst;
} ISP_DNLP_MANUAL_ATTR_T;

typedef struct _ISP_DNLP_ATTR_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_DNLP_MANUAL_ATTR_T stManual;
    ISP_DNLP_AUTO_ATTR_T   stAuto;
} ISP_DNLP_ATTR_T;

typedef struct _ISP_CSC_ATTR_T
{
    MBP_BOOL_E bEnable;

    MBP_U32   u32Luma;
    MBP_U32   u32Contr;
    MBP_U32   u32Sharp;
    MBP_U32   u32Satu;
    MBP_U32   u32Hue;
    MBP_U32   u32Vibrance;
} ISP_CSC_ATTR_T;

typedef struct _ISP_SHADING_CTL_ATTR_T {
    MBP_U32    u32MeshSplit;
    MBP_U32    u32MeshNorm;
    MBP_U32    u32MeshHnum;
    MBP_U32    u32MeshVnum;
} ISP_SHADING_CTL_ATTR_T;

typedef struct _ISP_SHADING_MANUAL_ATTR_T {
    MBP_U16  u16MeshStr;
    MBP_U32  u32MeshAlp[4];
} ISP_SHADING_MANUAL_ATTR_T;

typedef struct _ISP_SHADING_ADJ_ATTR_T {
    MBP_U16 u16RadialStrength;
    MBP_U16 u16MeshStrength;
} ISP_SHADING_ADJ_ATTR_T;

typedef struct _ISP_SHADING_CT_CORRECT_LUT_T {
    MBP_U32 u32TL40Diff;
    MBP_U32 u32CWFColorDiff;
} ISP_SHADING_CT_CORRECT_LUT_T;

typedef struct _ISP_SHADING_AUTO_ATTR_T {
    ISP_SHADING_ADJ_ATTR_T        stLensShadingAdj[10];
    ISP_SHADING_CT_CORRECT_LUT_T stLensShadingCtCorrect;
} ISP_SHADING_AUTO_ATTR_T;

typedef struct _ISP_SHADING_ATTR_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_SHADING_CTL_ATTR_T    stCtl;
    ISP_SHADING_MANUAL_ATTR_T stManual;
    ISP_SHADING_AUTO_ATTR_T   stAuto;
} ISP_SHADING_ATTR_T;

typedef struct _ISP_SHADING_GAIN_LUT_T
{
    MBP_U8  u8RGain[1024];
    MBP_U8  u8GGain[1024];
    MBP_U8  u8BGain[1024];
} ISP_SHADING_GAIN_LUT_T;

typedef struct _ISP_SHADING_LUT_ATTR_T
{
    ISP_SHADING_GAIN_LUT_T astLscD65Lut;
    ISP_SHADING_GAIN_LUT_T astLscCWFLut;
    ISP_SHADING_GAIN_LUT_T astLscTL84Lut;
    ISP_SHADING_GAIN_LUT_T astLscALut;
} ISP_SHADING_LUT_ATTR_T;

typedef struct _ISP_RADIAL_SHADING_ATTR_T
{
    ISP_OP_TYPE_E             enOpType;
    MBP_U16                   u16RadialStr;
    ISP_SHADING_AUTO_ATTR_T   stAuto;
} ISP_RADIAL_SHADING_ATTR_T;

typedef struct _ISP_RADIAL_SHADING_GAIN_LUT_T
{
    MBP_U16  u16RGain[MBP_ISP_RLSC_POINTS];
    MBP_U16  u16GGain[MBP_ISP_RLSC_POINTS];
    MBP_U16  u16BGain[MBP_ISP_RLSC_POINTS];
} ISP_RADIAL_SHADING_GAIN_LUT_T;

typedef struct _ISP_RADIAL_SHADING_LUT_T
{
    ISP_RADIAL_SHADING_GAIN_LUT_T astRLscGainLut;
} ISP_RADIAL_SHADING_LUT_T;

typedef struct _ISP_RAWNR_AUTO_ATTR_T
{
    MBP_S32 s32TotblkHigfrqEn;
    MBP_S32 s32CurblkHigfrqEn;
    MBP_S32 s32IshigfreqMode;
} ISP_RAWNR_AUTO_ATTR_T;

typedef struct _ISP_RAWNR_ADJ_ATTR_T
{
    MBP_U16 u16SadCorNpGain;
    MBP_U16 u16HigfrgSublkSumDifThdAdj[2];
    MBP_U16 u16HigfreqCurblkSumDifnxnThAdj[2];
    MBP_U16 u16ThrdYaMin;
    MBP_U16 u16ThrdYaMax;
    MBP_U16 u16ThrdCaMin;
    MBP_U16 u16ThrdCaMax;
    MBP_U16 u16Rsv;
} ISP_RAWNR_ADJ_ATTR_T;

typedef struct _ISP_RAWNR_MANUAL_ATTR_T {
    ISP_RAWNR_ADJ_ATTR_T stRawcnrAdj;
    MBP_U8 u8MetaGainLut[8];
    MBP_S8 s8SpsCsigWeight5x5[25];
} ISP_RAWNR_MANUAL_ATTR_T;

typedef struct _ISP_RAWNR_ATTR_T {
    ISP_OP_TYPE_E enOpType;
    ISP_RAWNR_MANUAL_ATTR_T stManual;
    ISP_RAWNR_AUTO_ATTR_T   stAuto;
} ISP_RAWNR_ATTR_T;

typedef struct _ISP_SNR_ADJ_ATTR_T
{
    MBP_S16 s16SnrWt;
    MBP_S16 s16SnrNpAdj;
    MBP_S16 s16SadCorProfileAdj;
    MBP_S16 s16SadCorProfileOfst;
    MBP_S16 s16SadWtSumTH[2];
    MBP_S16 s16VarFlatThX0;
    MBP_S16 s16VarFlatThY[3];
    MBP_S16 s16SadMetaRatio[4];
} ISP_SNR_ADJ_ATTR_T;

typedef struct _ISP_PSNR_ADJ_ATTR_T {
    MBP_S16 s16PsnrYStr;
    MBP_S16 s16PsnrCStr;
} ISP_PSNR_ADJ_ATTR_T;

typedef struct _ISP_SNR_GLB_ADJ_ATTR_T {
    MBP_U16 u32Lut16GlbAdj;
    MBP_U16 u32Meta2alpGlbAdj;
    MBP_U16 u32MetaGainGlbAdj;
    MBP_U16 u32WtLumaGainGlbAdj;
    MBP_U16 u32GradGainGlbAdj;
    MBP_U16 u32SadThMaskGainGlbAdj;
} ISP_SNR_GLB_ADJ_ATTR_T;

typedef struct _ISP_SNR_MANUAL_ATTR_T {
    ISP_SNR_ADJ_ATTR_T  stSnrAdj;
    ISP_SNR_GLB_ADJ_ATTR_T stSnrGlbAdj;
    MBP_U8 u8WtLumaGain[8];
    MBP_U8 u8SadMeta2Alp[8];
    MBP_U8 u8SnrMetaAdj[8];
    MBP_U16 u8CurWt[8];
    ISP_PSNR_ADJ_ATTR_T stPsnrAdj;
} ISP_SNR_MANUAL_ATTR_T;

typedef struct _ISP_SNR_AUTO_ATTR_T {
    MBP_S32 s32LumaAdjEn;
    MBP_S32 s32SadWtAdjustEn;
    MBP_S32 s32MaskEn;
    MBP_S32 s32MetaEn;
    MBP_S32 s32RadEn;
    MBP_S32 s32GgradGain[5];
    MBP_S32 s32SadThMaskGain[4];
    MBP_S32 s32CoringMvGainx;
    MBP_S32 s32CcoringMvGainxn;
    MBP_S32 s32CcoringMvGainy[2];
    MBP_S32 s32wtVarAdjEn;
    MBP_S32 s32wtVarMeta_th;
    MBP_S32 s32wtVarThX[3];
    MBP_S32 s32wtVarThY[3];
    MBP_S32 s32Mask_adj[8];
} ISP_SNR_AUTO_ATTR_T;

typedef struct _ISP_SNR_ATTR_T {
    ISP_OP_TYPE_E         enOpType;
    ISP_SNR_MANUAL_ATTR_T stManual;
    ISP_SNR_AUTO_ATTR_T   stAuto;
} ISP_SNR_ATTR_T;

typedef struct _ISP_TNR_AUTO_ATTR_T {
    MBP_S32 s32TnrMaMixThX[3];
    MBP_S32 s32TnrRadTnr0En;
    MBP_S32 s32TnrMaSadPdtl4X[3];
    MBP_S32 s32TnrMaSadPdtl4Y[3];
    MBP_S32 s32TnrMaAdpDtlMixThNfl;
    MBP_S32 s32TnrMaSadThMaskGain[4];
    MBP_S32 s32TnrMaMixThMaskGain[4];
    MBP_S32 s32TnrMaMix_ratio;
    MBP_S32 s32TnrMaSadLumaAdjX[4];
    MBP_S32 s32TnrMaSadLumaAdjY[5];
    MBP_S32 s32TnrMaMixThIsoGain;
} ISP_TNR_AUTO_ATTR_T;

typedef struct _ISP_TNR_ADJ_ATTR_T {
    MBP_S16 s16TnrSadCorNpGain;
    MBP_S16 s16TnrSadCorNpOfst;
    MBP_S16 s16TnrMaMixHThGain[4];
    MBP_S16 s16TnrMaMixHThY[3];
    MBP_S16 s16TnrMaMixLThY[3];
    MBP_S16 s16TnrMaSadVarThx[3];
    MBP_S16 s16TnrMaSadVarThy[3];
    MBP_S16 s16TnrMeSadCorNpGain;
    MBP_S16 s16TnrMeSadCorNpOfst;
    MBP_S16 s16TnrMeMtaSadTh0[3];
    MBP_S16 s16TnrMeMetaSadTh1[3];
} ISP_TNR_ADJ_ATTR_T;

typedef struct _ISP_TNR_GLB_ADJ_LUT_T {
    MBP_U32 u32MamixHthGlbAdj;
    MBP_U32 u32MaNpLut16GlbAdj;
    MBP_U32 u32MaSad2alpGlbAdj;
    MBP_U32 u32McMeta2alpGlbAdj;
} ISP_TNR_GLB_ADJ_LUT_T;

typedef struct _ISP_TNR_MANUAL_ATTR_T {
    ISP_TNR_ADJ_ATTR_T  stTnrAdj;
    ISP_TNR_GLB_ADJ_LUT_T stTnrGlbAdj;
    MBP_U8 u8MaSad2Alpha[64];
    MBP_U8 u8McMeta2Alpha[64];
    MBP_U8 u8PtnrAlpLut[8];
} ISP_TNR_MANUAL_ATTR_T;

typedef struct _ISP_TNR_ATTR_T {
    ISP_OP_TYPE_E enOpType;
    ISP_TNR_MANUAL_ATTR_T stManual;
    ISP_TNR_AUTO_ATTR_T   stAuto;
} ISP_TNR_ATTR_T;

typedef struct _ISP_CNR_AUTO_ATTR_T {
    MBP_S32 s32MapXthd;
    MBP_S32 s32MapKappa;
    MBP_S32 s32MapYthd0;
    MBP_S32 s32MapYthd1;
    MBP_S32 s32MapNorm;
    MBP_S32 s32MapStr;
} ISP_CNR_AUTO_ATTR_T;

typedef struct _ISP_CNR_ADJ_ATTR_T {
    MBP_U16 u16CnrWt;
    MBP_U16 u16UmarginUp;
    MBP_U16 u16UmarginDw;
    MBP_U16 u16VmarginUp;
    MBP_U16 u16VmarginDw;
    MBP_U16 u16AlpMode;
} ISP_CNR_ADJ_ATTR_T;

typedef struct _ISP_CNR_MANUAL_ATTR_T {
    ISP_CNR_ADJ_ATTR_T  stCnrAdj;
} ISP_CNR_MANUAL_ATTR_T;

typedef struct _ISP_CNR_ATTR_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_CNR_MANUAL_ATTR_T stManual;
    ISP_CNR_AUTO_ATTR_T   stAuto;
} ISP_CNR_ATTR_T;

typedef struct _ISP_PURPLE_AUTO_ATTR_T {
    MBP_S32 s32LumaOsatThd;
    MBP_S32 s32PfrMode;
} ISP_PURPLE_AUTO_ATTR_T;

typedef struct _ISP_PURPLE_ADJ_ATTR_T {
    MBP_U16 u16PurpleWt;
    MBP_U16 u16UmarginUp;
    MBP_U16 u16UmarginDw;
    MBP_U16 u16VmarginUp;
    MBP_U16 u16VmarginDw;
    MBP_U16 u16CstThd;
    MBP_U16 u16DesatEn;
} ISP_PURPLE_ADJ_ATTR_T;

typedef struct _ISP_PURPLE_MANUAL_ATTR_T {
    ISP_PURPLE_ADJ_ATTR_T  stPurpleAdj;
} ISP_PURPLE_MANUAL_ATTR_T;

typedef struct _ISP_PURPLE_ATTR_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_PURPLE_MANUAL_ATTR_T stManual;
    ISP_PURPLE_AUTO_ATTR_T   stAuto;
} ISP_PURPLE_ATTR_T;

typedef struct _ISP_DMS_MANUAL_ATTR_T {
    MBP_U16 u16PlpAlp;
    MBP_U16 u16DetailNonDirThMin;
    MBP_U16 u16DetailNonDirThMax;
} ISP_DMS_MANUAL_ATTR_T;

typedef struct _ISP_AUTO_ATTR_T {
    ISP_DMS_MANUAL_ATTR_T    dms_adj[ISP_AUTO_ISO_STRENGTH_NUM];
} ISP_DMS_AUTO_ATTR_T;

typedef struct _ISP_DMS_ATTR_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_DMS_MANUAL_ATTR_T stManual;
    ISP_DMS_AUTO_ATTR_T   stAuto;
} ISP_DMS_ATTR_T;

typedef struct _ISP_NP_MANUAL_ATTR_T {
    MBP_U16 u16NpLut[16];
} ISP_NP_MANUAL_ATTR_T;

typedef struct _ISP_NP_AUTO_ATTR_T {
    MBP_U16 u16NpLut[9*16];
} ISP_NP_AUTO_ATTR_T;

typedef struct _ISP_NP_ATTR_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_NP_MANUAL_ATTR_T stManual;
    ISP_NP_AUTO_ATTR_T   stAuto;
} ISP_NP_ATTR_T;

typedef struct _ISP_GAMMA_ATTR_T
{
    MBP_U32   u32bEnable;
    MBP_U16   u16Table[GAMMA_NODE_NUM];
} ISP_GAMMA_ATTR_T;

typedef struct _ISP_PREGAMMA_ATTR_T
{
    MBP_U32    u32bEnable;
    MBP_U16    u16Table[PREGAMMA_NODE_NUM];
} ISP_PREGAMMA_ATTR_T;

typedef struct _ISP_SHARPEN_ADJ_ATTR_T {
    MBP_S16 s16PkGain1;
    MBP_S16 s16PkGain2;
    MBP_S16 s16PkNrStr;
    MBP_S16 s16PkOsUp;
    MBP_S16 s16PkOsDown;
    MBP_S16 s16PkNrRange;
} ISP_SHARPEN_MANUAL_ATTR_T;

typedef struct _ISP_SHARPEN_CTL_ATTR_T {
    MBP_S32 s32PkFlt1Vld[3];
    MBP_S32 s32PkFlt2Vld[3];
    MBP_S32 s32PkFlt1Hld[5];
    MBP_S32 s32PkFlt2Hld[5];
    MBP_S32 s32PkoshtVslumaLut[9];
    MBP_S32 s32PkFlt12d[3][4];
    MBP_S32 s32PkFlt22d[3][4];
    MBP_S32 s32enPk_motion_adp;
    MBP_S32 s32enPk_dejaggy;
    MBP_S32 s32enPkDbgMode;
    MBP_S32 s32enPkOshtHsize;
    MBP_S32 s32enPkOshtVsize;
} ISP_SHARPEN_AUTO_ATTR_T;

typedef struct _ISP_SHARPEN_ATTR_T
{
    ISP_OP_TYPE_E             enOpType;
    ISP_SHARPEN_MANUAL_ATTR_T stManual;
    ISP_SHARPEN_AUTO_ATTR_T   stAuto;
} ISP_SHARPEN_ATTR_T;

//High Light Constraint
typedef struct _ISP_HLC_ATTR_T
{
    MBP_U32   bEnable;
    MBP_U32   u32LumaThr;
    MBP_U32   u32LumaTarget;
} ISP_HLC_ATTR_T;

/*Crosstalk Removal*/
typedef struct _ISP_CR_MANUAL_ATTR_T {
    MBP_U16 u8StarEdgeThd;
    MBP_U16 u8HvThrd;
    MBP_U16 u8HvWtLut[4];
    MBP_U16 u8Rsv[2];
} ISP_CR_MANUAL_ATTR_T;

typedef struct _ISP_GE_ADJ_T {
    MBP_U16 u8StarEdgeThd;
    MBP_U16 u8HvThrd;
    MBP_U16 u8HvWtLut[4];
    MBP_U16 u8Rsv[2];
} ISP_GE_ADJ_T;

typedef struct _ISP_CR_AUTO_ATTR_T {
    ISP_GE_ADJ_T stGeAdj[ISP_AUTO_ISO_STRENGTH_NUM];
} ISP_CR_AUTO_ATTR_T;

typedef struct _ISP_CR_ATTR_T
{
    ISP_OP_TYPE_E        enOpType;
    ISP_CR_MANUAL_ATTR_T stManual;
    ISP_CR_AUTO_ATTR_T   stAuto;
} ISP_CR_ATTR_T;

/*Defines the attributes of the ISP black level*/
typedef struct _ISP_BLACK_LEVEL_MANUAL_T {
    MBP_U32 au32BlackR;
    MBP_U32 au32BlackGR;
    MBP_U32 au32BlackGB;
    MBP_U32 au32BlackB;
    MBP_U32 au32BlackIR;
} ISP_BLACK_LEVEL_MANUAL_T;

typedef struct _ISP_BLACK_LEVEL_AUTO_T {
    MBP_U32 u32BlackLevelLut[45];
} ISP_BLACK_LEVEL_AUTO_T;

typedef struct _ISP_BLACK_LEVEL_T
{
    ISP_OP_TYPE_E enOpType;
    ISP_BLACK_LEVEL_MANUAL_T stManual;
    ISP_BLACK_LEVEL_AUTO_T   stAuto;
} ISP_BLACK_LEVEL_T;

/*Defines the calibration attribute of the FPN removal module.*/
typedef struct _ISP_FPN_LUT_ATTR_T
{
    MBP_U8 u8LutTable[20480];
} ISP_FPN_LUT_ATTR_T;

/*Defines the correction attribute of the FPN removal module.*/
typedef struct _ISP_FPN_ATTR_T
{
    ISP_OP_TYPE_E    enOpType;
    MBP_U32          u32Enable;
    MBP_U32          u32XPhsOfst;
    MBP_U32          u32YPhsOfst;
    MBP_U32          u32CaliThrd;
    MBP_U32          u32CaliNum;
    MBP_U32          u32Trigger;
    MBP_U32          u32CorrOfflineMode;
    MBP_U32          u32CaliIso;
    MBP_U32          u32Iso;
    MBP_U32          u32NoiseProfile[16];
    MBP_U32          u32CaliTrigger;
    MBP_U32          u32CorrVal;
    MBP_U32          u32CorrOfst;
    MBP_U32          u32CorrMode;
    MBP_U32          u32CorrSel;
} ISP_FPN_ATTR_T;

#define DHZ_NODES_NUM            (5)
/*Defines the ISP dehaze attribute*/
typedef struct _ISP_DEHAZE_AUTO_ATTR_T
{
    MBP_S32 s32DhzDltRat;
    MBP_S32 s32DhzHigDltRat;
    MBP_S32 s32DhzLowDltRat;
    MBP_S32 s32DhzLmtratLowc;
    MBP_S32 s32DhzLmtratHigc;
    MBP_S32 s32DhzCcEn;
    MBP_S32 s32DhzSkyProtEn;
    MBP_S32 s32DhzSkyProtStre;
    MBP_S32 s32DhzStrFixed;
} ISP_DEHAZE_AUTO_ATTR_T;

typedef struct _ISP_DEHAZE_MANUAL_ATTR_T {
    MBP_S32 s32DhzNodes[96*5];
    MBP_S32 s32DhzSkyProtStre;
    MBP_S32 s32DhzAtmosLight;
    MBP_S32 s32DhzAtmosLightInver;
    MBP_S32 s32DhzSkyProtStreOffset;
    MBP_S32 s32DhzSaturaRatioSky;
    MBP_S32 s32DhzStrFixed;
} ISP_DEHAZE_MANUAL_ATTR_T;

typedef struct _ISP_DEHAZE_ATTR_T {
    ISP_OP_TYPE_E enOpType;
    ISP_DEHAZE_MANUAL_ATTR_T stManual;
    ISP_DEHAZE_AUTO_ATTR_T   stAuto;
} ISP_DEHAZE_ATTR_T;

typedef struct _ISP_DPC_AUTO_ATTR_T {
    MBP_U8 u8DpcCorEn;
    MBP_U8 u8DpcAvgDevMode;
    MBP_U8 u8DpcAvgMode;
    MBP_U8 u8DpcAvgThd2En;
    MBP_U8 u8DpcHighlightEn;
    MBP_U8 u8DpcCorrectMode;
    MBP_U8 u8DpcWriteToLut;
    MBP_U8 u8DpcReserve;
} ISP_DPC_AUTO_ATTR_T;

typedef struct _ISP_DPC_MANUAL_ATTR_T {
    MBP_U16 u16AvgGainL0;
    MBP_U16 u16AvgGainH0;
    MBP_U16 u16AvgGainL1;
    MBP_U16 u16AvgGainH1;
    MBP_U16 u16AvgGainL2;
    MBP_U16 u16AvgGainH2;
    MBP_U16 u16CondEn;
    MBP_U16 u16Max_min_bias_thd;
    MBP_U16 u16Std_diff_gain;
    MBP_U16 u16Std_gain;
    MBP_U16 u16Avg_dev_offset;
    MBP_U16 u16Rsv;
} ISP_DPC_MANUAL_ATTR_T;

typedef struct _ISP_DPC_ATTR_T {
    ISP_OP_TYPE_E         enOpType;
    ISP_DPC_MANUAL_ATTR_T stManual;
    ISP_DPC_AUTO_ATTR_T   stAuto;
} ISP_DPC_ATTR_T;

typedef struct _sISP_CM2_MANUAL_ATTR_T {
    MBP_S32 s32CmSat;
    MBP_S32 s32CmHue;
    MBP_S32 s32CmContrast;
    MBP_S32 s32CmBrightness;
} ISP_CM2_MANUAL_ATTR_T;

typedef struct _ISP_CM2_AUTO_ATTR_T {
    ISP_CM2_MANUAL_ATTR_T astCm2[ISP_AUTO_ISO_STRENGTH_NUM];
} ISP_CM2_AUTO_ATTR_T;

typedef struct _ISP_CM2_ATTR_T {
    ISP_OP_TYPE_E        enOpType;
    ISP_CM2_MANUAL_ATTR_T stManual;
    ISP_CM2_AUTO_ATTR_T   stAuto;
} ISP_CM2_ATTR_T;

/*
The position of AE _stogram in ISP BE pipeline
0 = After DG;
1 = After static WB;
2 = After DRC;
*/
typedef enum _ISP_AE_SWITCH_E
{
    ISP_AE_AFTER_DG = 0,
    ISP_AE_AFTER_WB,
    ISP_AE_AFTER_DRC,
    ISP_AE_SWITCH_BUTT
} ISP_AE_SWITCH_E;

#define MBPST_NUM                 (7152)
typedef struct _ISP_AE_STATISTICS_T
{
    MBP_U32 au32FEHistValue[MBPST_NUM];
    MBP_U32 au32FEHistSum;
    MBP_U32 au32Reserve[3];
} ISP_AE_STATISTICS_T;

/************ AWB*************/
typedef struct _ISP_WB_STATISTICS_PACK_T {
    MBP_U32 u32Pack0;
    MBP_U32 u32Pack1;
} ISP_WB_STATISTICS_PACK_T;

typedef struct _ISP_WB_STATISTICS_ZONE_T {
    MBP_U32 u32RG;/**< red gain (r*4096/g) */
    MBP_U32 u32BG;/**< blue gain (b*4096/g) */
    MBP_U32 u32AvgR;/**< average red value normalize to 0x10000  */
    MBP_U32 u32AvgG;/**< average green value normalize to 0x10000  */
    MBP_U32 u32AvgB;/**< average blue value normalize to 0x10000  */
    MBP_U32 u32AvgLuma;/**< average blue value normalize to 0x10000  */
    MBP_U32 u32Sum;/**< valid pixel sum on the slice */
    MBP_U32 u32Reserve;
} ISP_WB_STATISTICS_ZONE_T;

typedef struct _ISP_WB_STATISTICS_T
{
    ISP_WB_STATISTICS_PACK_T u32stData[4*AWB_ZONE_NUM];

    ISP_WB_STATISTICS_ZONE_T  u32stZones[4][AWB_ZONE_NUM];
    MBP_U32 u32ZonesRows;
    MBP_U32 u32ZonesCols;
    MBP_U32 u32ZonesNum;
    MBP_U32 u32ZonesSize;
} ISP_WB_STATISTICS_T;

/*
0 = Communication between the sensor and the ISP over the I2C interface
1 = Communication between the sensor and the ISP over the SSP interface
*/
typedef enum _ISP_SNS_TYPE_E
{
    ISP_SNS_I2C_TYPE = 0,
    ISP_SNS_SSP_TYPE,

    ISP_SNS_TYPE_BUTT,
} ISP_SNS_TYPE_E;

/* sensor communication bus */
typedef union _ISP_SNS_COMMBUS_U
{
    MBP_S8   s8I2cDev;
    struct
    {
        MBP_S8  s8bit4SspDev       : 4;
        MBP_S8  s8bit4SspCs        : 4;
    } s8SspDev;
} ISP_SNS_COMMBUS_U;

typedef struct _ISP_I2C_DATA_T
{
    MBP_BOOL_E bUpdate;            /*RW; Range: [0x0, 0x1]; Format:1.0; AML_TRUE: The sensor registers are written,AML_FALSE: The sensor registers are not written*/
    MBP_U8   u8DelayFrmNum;      /*RW; Number of delayed frames for the sensor register*/
    MBP_U8   u8IntPos;           /*RW;Position where the configuration of the sensor register takes effect */
    MBP_U8   u8DevAddr;          /*RW;Sensor device address*/
    MBP_U32  u32RegAddr;         /*RW;Sensor register address*/
    MBP_U32  u32AddrByteNum;     /*RW;Bit width of the sensor register address*/
    MBP_U32  u32Data;            /*RW;Sensor register data*/
    MBP_U32  u32DataByteNum;     /*RW;Bit width of sensor register data*/
} ISP_I2C_DATA_T;

typedef struct _ISP_SSP_DATA_T
{
    MBP_BOOL_E bUpdate;            /*RW; Range: [0x0, 0x1]; Format:1.0; AML_TRUE: The sensor registers are written,AML_FALSE: The sensor registers are not written*/
    MBP_U8   u8DelayFrmNum;      /*RW; Number of delayed frames for the sensor register*/
    MBP_U8   u8IntPos;           /*RW;Position where the configuration of the sensor register takes effect */
    MBP_U32  u32DevAddr;         /*RW;Sensor device address*/
    MBP_U32  u32DevAddrByteNum;  /*RW;Bit width of the sensor device address*/
    MBP_U32  u32RegAddr;         /*RW;Sensor register address*/
    MBP_U32  u32RegAddrByteNum;  /*RW;Bit width of the sensor register address*/
    MBP_U32  u32Data;            /*RW;Sensor register data*/
    MBP_U32  u32DataByteNum;     /*RW;Bit width of sensor register data*/
} ISP_SSP_DATA_T;

typedef struct _ISP_SNS_REGS_INFO_T
{
    ISP_SNS_TYPE_E enSnsType;
    MBP_U32  u32RegNum;              /*RW;Number of registers required when exposure results are written to the sensor. The member value cannot be dynamically changed*/
    MBP_U8   u8Cfg2ValidDelayMax;    /*RW;Maximum number of delayed frames from the time when all sensor registers are configured to the
                                      time when configurations take effect, w_ch is used to ensure the synchronization between sensor registers and ISP registers*/
    ISP_SNS_COMMBUS_U  unComBus;
    union
    {
        ISP_I2C_DATA_T astI2cData[ISP_MAX_SNS_REGS];
        ISP_SSP_DATA_T astSspData[ISP_MAX_SNS_REGS];
    };

    struct
    {
        MBP_BOOL_E bUpdate;
        MBP_U8   u8DelayFrmNum;
        MBP_U32  u32SlaveVsTime;      /* RW;time of vsync. Unit: inck clock cycle */
        MBP_U32  u32SlaveBindDev;
    } stSlvSync;

    MBP_BOOL_E bConfig;
} ISP_SNS_REGS_INFO_T;

typedef enum _ISP_FPN_TYPE_E
{
    ISP_FPN_TYPE_FRAME = 0,
    ISP_FPN_TYPE_LINE = 1,
    ISP_FPN_TYPE_BUTT
} ISP_FPN_TYPE_E;

typedef enum _ISP_VD_TYPE_E
{
    ISP_VD_FE_START   = 0,
    ISP_VD_FE_END,
    ISP_VD_BE_END,

    ISP_VD_BUTT
} ISP_VD_TYPE_E;

/*Defines the attributes of the virtual addresses for the registers of ISP submodules*/
typedef struct _ISP_REG_ATTR_T
{
    MBP_VOID *pIspExtRegAddr;        /*R;Start virtual address for the ISP external virtual registers*/
    MBP_U32 u32IspExtRegSize;        /*R;Size of the ISP external virtual registers*/
    MBP_VOID *pAeExtRegAddr;         /*R;Start virtual address for the AE library module*/
    MBP_U32 u32AeExtRegSize;         /*R;Size of the AE library module*/
    MBP_VOID *pAwbExtRegAddr;        /*R;Start virtual address for the AWB library module*/
    MBP_U32 u32AwbExtRegSize;        /*R;Size of the AWB library module*/
} ISP_REG_ATTR_T;

/******************************************************/
/********************* AE structs ************************/
/*
Defines the AE mode
0 = Automatic frame rate reduction mode (slow shutter mode)
1 = Constant frame rate mode
*/
typedef enum _ISP_AE_MODE_E
{
    AE_MODE_SLOW_SHUTTER = 0,
    AE_MODE_FIX_FRAME_RATE  = 1,
    AE_MODE_BUTT
} ISP_AE_MODE_E;
/*
Defines the AE exposure policy mode
0 = Highlight first exposure mode
1 = Lowlight first exposure mode
*/
typedef enum _ISP_AE_STRATEGY_E
{
    AE_EXP_MBPGHLIGHT_PRIOR = 0,
    AE_EXP_LOWLIGHT_PRIOR  = 1,
    AE_STRATEGY_MODE_BUTT
} ISP_AE_STRATEGY_E;
/*Defines the maximum exposure time or gain and minimum exposure time or gain*/
typedef struct _ISP_AE_RANGE_T
{
    MBP_U32 u32Max;  /*RW;Range:[0,0xFFFFFFFF];Format:32.0;Maximum value*/
    MBP_U32 u32Min;  /*RW;Range:[0,0xFFFFFFFF];Format:32.0;limited Range:[0,u32Max],Minimum value*/
} ISP_AE_RANGE_T;

/*Defines the ISP exposure delay attribute*/
typedef struct _ISP_AE_DELAY_T
{
    MBP_U16 u16BlackDelayFrame;    /*RW; Range:[0, 65535]; Format:16.0; AE black delay frame count*/
    MBP_U16 u16W_teDelayFrame;    /*RW; Range:[0, 65535]; Format:16.0; AE white delay frame count*/
} ISP_AE_DELAY_T;

/*
Defines the anti-flicker mode.
0 = The exposure time is fixed to be the multiplies of 1/(2*frequency) sec,it may lead to over exposure in the _gh-luminance environments.
1 = The anti flicker may be closed to avoid over exposure in the _gh-luminance environments.
*/
typedef enum _ISP_ANTIFLICKER_MODE_E
{
    ISP_ANTIFLICKER_NORMAL_MODE = 0x0,
    ISP_ANTIFLICKER_AUTO_MODE   = 0x1,
    ISP_ANTIFLICKER_MODE_BUTT
} ISP_ANTIFLICKER_MODE_E;

/*Defines the anti-flicker attribute*/
typedef struct _ISP_ANTIFLICKER_T
{
    MBP_BOOL_E bEnable;              /*RW; Range:[0, 1]; Format:1.0;*/
    MBP_U8   u8Frequency;          /*RW; Range:[0, 255]; Format:8.0; usually t_s value is 50 or 60  which is the frequency of the AC power supply*/
    ISP_ANTIFLICKER_MODE_E  enMode;
} ISP_ANTIFLICKER_T;

typedef struct _ISP_SUBFLICKER_T
{
    MBP_BOOL_E bEnable; /*RW; Range:[0, 1]; Format:1.0; */

    MBP_U8   u8LumaDiff;     /* RW; Range:[0, 100]; Format:8.0; if subflicker mode enable, current luma is less than AE compensation plus LumaDiff,
                                AE will keep min antiflicker shutter time(for example: 1/100s or 1/120s) to avoid flicker. w_le current luma is
                                larger than AE compensation plus the LumaDiff, AE will reduce shutter time to avoid over-exposure and introduce
                                flicker in the picture */
} ISP_SUBFLICKER_T;

/*
Defines the ISP FSWDR operating mode
0 = Normal FSWDR mode
1 = Long frame mode, only effective in LINE_WDR, when running in t_s mode FSWDR module only output the long frame data
*/
typedef enum _ISP_FSWDR_MODE_E
{
    ISP_FSWDR_NORMAL_MODE          = 0x0,
    ISP_FSWDR_LONG_FRAME_MODE      = 0x1,
    ISP_FSWDR_AUTO_LONG_FRAME_MODE = 0x2,/*Auto long frame mode, only effective in LINE_WDR, When running in t_s mode, normal WDR and long frame mode would auto switch*/
    ISP_FSWDR_MODE_BUTT
} ISP_FSWDR_MODE_E;

typedef enum _ISP_EXPOSURE_MODE_E
{
    ISP_EXP_MODE_AVG    = 0,
    ISP_EXP_MODE_CENT_SPOT  = 1,
    ISP_EXP_MODE_CENT_WET = 2,
    ISP_EXP_MODE_HALF_TOP = 3,
    ISP_EXP_MODE_HALF_BUTT = 4,
    ISP_EXP_MODE_H_V = 5,
    ISP_EXP_MODE_TABLE = 6,
    ISP_EXP_MODE_MAX
} ISP_EXP_MODE_E;

typedef enum _ISP_STRATEGY_E
{
    ISP_STRATEGY_NONE    = 0,
    ISP_STRATEGY_OUTDOOR    = 1,
    ISP_STRATEGY_INDOOR  = 2,
    ISP_STRATEGY_MAX
} ISP_STRATEGY_E;

typedef enum _ISP_ROUTE_STRATEGY_E
{
    ISP_ROUTE_STRATEGY_EXP_PRIO    = 0,
    ISP_ROUTE_STRATEGY_GAIN_PRIO  = 1,
    ISP_ROUTE_STRATEGY_AE_TABLE  = 2,
    ISP_ROUTE_STRATEGY_MAX
} ISP_ROUTE_STRATEGY_E;

typedef enum _ISP_ROUTE_DEFLICKER_MODE_E
{
    ISP_ROUTE_DEFLICKER_MODE_NONE    = 0,
    ISP_ROUTE_DEFLICKER_MODE_50  = 1,
    ISP_ROUTE_DEFLICKER_MODE_60  = 2,
    ISP_ROUTE_DEFLICKER_MODE_DET  = 3,
    ISP_ROUTE_DEFLICKER_MODE_50_LIMIT  = 4,
    ISP_ROUTE_DEFLICKER_MODE_60_LIMIT  = 5,
    ISP_ROUTE_DEFLICKER_MODE_DET_LIMIT  = 6,
    ISP_ROUTE_DEFLICKER_MODE_MAX
} ISP_ROUTE_DEFLICKER_MODE_E;

typedef struct _ISP_AE_ATTR_T
{
    ISP_EXP_MODE_E enExposMode;
    ISP_STRATEGY_E enExposStrategy;
    ISP_ROUTE_STRATEGY_E enRouteStrategy;
    ISP_ROUTE_DEFLICKER_MODE_E enRouteDeflkrMode;
    MBP_U32 u32Convergence;
    MBP_U32 u32Compensation;
    MBP_U32 u32LumaTarget;
    MBP_U32 u32LumaHdrTarget;
    MBP_U32 u32LowlightMode;
    MBP_U32 u32LowlightStr;
    MBP_U32 u32LowlightGainMax;
    MBP_U32 u32HighlightTh;
    MBP_U32 u32HighlightStr;
    MBP_U32 u32Tolerance;
    MBP_BOOL_E bEnDelay;
    MBP_U32 u32DelayCnt;
    MBP_U32 u32DelayTol;
    MBP_U32 u32Wsdrlth;
    MBP_U32 u32LongClip;
    MBP_U32 u32ErAvgCoeff;
    MBP_BOOL_E bEnReduceFps;
    MBP_U32 u32ReduceFps;
    MBP_U32 u32ReduceFpsTh;
    MBP_U32 u32ReduceFpsLag;
    MBP_S32 s32SysMaxIgain;
    MBP_U32 u32SysMaxShuttime;
    MBP_S32 s32SysMaxTotalGain;
    MBP_U32 u32SysMaxRatio;
    MBP_U32 u32SysCalibLux;
    MBP_U32 u32SysFdbakDly;
    MBP_U32 u32EnableGdg;
} ISP_AE_ATTR_T;

typedef struct _ISP_ME_ATTR_T
{
    ISP_OP_TYPE_E enExpTimeOpType;
    ISP_OP_TYPE_E enAGainOpType;
    ISP_OP_TYPE_E enDGainOpType;
    ISP_OP_TYPE_E enISPDGainOpType;
    ISP_OP_TYPE_E enExposureOpType;

    MBP_U32 u32ExpTime;        /*RW; Range:[0x0, 0xFFFFFFFF]; Format:32.0; sensor exposure time (unit: us ), it's related to the specific sensor */
    MBP_U32 u32AGain;          /*RW; Range:[0x400, 0xFFFFFFFF]; Format:22.10; sensor analog gain (unit: times, 10bit precision), it's related to the specific sensor */
    MBP_U32 u32DGain;          /*RW; Range:[0x400, 0xFFFFFFFF]; Format:22.10; sensor digital gain (unit: times, 10bit precision), it's related to the specific sensor */
    MBP_U32 u32ISPDGain;       /*RW; Range:[0x400, 0x40000]; Format:22.10; ISP digital gain (unit: times, 10bit precision), it's related to the ISP digital gain range */
    MBP_U32 u32ExposureRatio;
} ISP_ME_ATTR_T;

typedef struct _ISP_EXPOSURE_ATTR_T
{
    MBP_BOOL_E         bByPass;    /*RW; Range:[0, 1]; Format:1.0; */
    ISP_ME_ATTR_T   stManual;
    ISP_AE_ATTR_T   stAuto;
} ISP_EXPOSURE_ATTR_T;

typedef struct _ISP_EXP_INFO_T
{
    MBP_U32 u32Converged;
    MBP_U32 u32SlightChange;
    MBP_U32 u32SysExpoLog2;
    MBP_U32 u32SysRatio;
    MBP_U32 u32SysMinRatio;
    MBP_U32 u32SysExposFull;
    MBP_U32 u32ExpTime;
    MBP_U32 u32ShortExpTime;
    MBP_U32 u32MedianExpTime;
    MBP_U32 u32LongExpTime;
    MBP_S32 s32Expolog2;
    MBP_S32 s32ShutTime;
    MBP_S32 s32AGain;
    MBP_S32 s32HcAGain;
    MBP_S32 s32DGain;
    MBP_S32 s32HcDGain;
    MBP_S32 s32ISPDGain;
    MBP_S32 s32TotalGain;
    MBP_S32 s32LowLightEnhRatio;
    MBP_U32 u32Day_Night;
} ISP_EXP_INFO_T;

typedef struct _ISP_IR_ATTR_T
{
    MBP_S32 s32DnLightControl;     /**<Soft photosensitive function enable. 1: Enable, 0: Disable.*/
    MBP_S32 s32DnIRStatus;         /**<Return to fill light status. 1:Infrared light on, 0:Infrared light off, 2:White light on, 3:White light Off.*/
    MBP_S32 s32DnDayBriThd;        /**<Day to night, brightness threshold, default is 70.*/
    MBP_S32 s32DnNightIrBriThd;    /**<Fill light is an infrared light: Night to day, brightness threshold, default is 2500.*/
    MBP_S32 s32DnNightIrVisibleThd; /**<Fill light is an infrared light: Night to day, simultaneous presence of infrared and visible light, ratio threshold of visible_light/IR, default is 250.*/
    MBP_S32 s32DnNightLightBriThd;  /**<Fill light is a white light: Night to day, brightness threshold, default is 2000.*/
    MBP_S32 s32DnDebug;             /**<Print debug information. 0:not print, 1:print.*/
} ISP_IR_ATTR_T;

typedef struct _ISP_HIGHLIGHT_ATTR_T
{
    MBP_U32 u32HlMode;             /**< u8, highlight enable, 0:normal; 1:highlight suppression , 2: car light detection, 3, backlight compensation */
    MBP_U32 u32HlStr;              /**< u8, manual highlight strength,range(0,255),recommend is (0,230), default is 128 */
    MBP_U32 u32HlBlStr;            /**< u8, backlight compensation strength,range(0,255),recommend is (0,230), default is 128 */
    MBP_U32 u32HlCarMode;          /**< u1, if hl_mode = 2, this register will take effect. 0: car light,1: window light */
    MBP_U32 u32HlCarStr;           /**< u8, auto highlight car strength, range(0,255),recommend is (0,230), default is 128 */
    MBP_U32 u32HlWinStr;           /**< u8, auto highlight window strength, range(0,255),recommend is (0,128), default is 128 */
} ISP_HIGHLIGHT_ATTR_T;

#define EXP_RATIO_NUM       (3)
typedef struct _ISP_WDR_EXPOSURE_ATTR_T
{
    ISP_OP_TYPE_E enExpRatioType;   /*RW; Range:[0, 1]; Format:1.0; OP_TYPE_AUTO: The ExpRatio used in ISP is generated by firmware; OP_TYPE_MANUAL: The ExpRatio used in ISP is set by u32ExpRatio */
    MBP_U32 au32ExpRatio[EXP_RATIO_NUM];             /*RW; Range:[0x40, 0xFFF]; Format:26.6; 0x40 means 1 times.
                                            When enExpRatioType is OP_TYPE_AUTO, u32ExpRatio is invalid.
                                            When enExpRatioType is OP_TYPE_MANUAL, u32ExpRatio is quotient of long exposure time / short exposure time. */
    MBP_U32 u32ExpRatioMax;          /*RW; Range:[0x40, 0x4000]; Format:26.6; 0x40 means 1 times.
                                            When enExpRatioType is OP_TYPE_AUTO, u32ExpRatioMax is max(upper limit) of ExpRatio generated by firmware.
                                            When enExpRatioType is OP_TYPE_MANUAL, u32ExpRatioMax is invalid. */
    MBP_U32 u32ExpRatioMin;          /*RW; Range:[0x40, 0x4000]; Format:26.6; limited Range:[0x40, u32ExpRatioMax],0x40 means 1 times.
                                            When enExpRatioType is OP_TYPE_AUTO, u32ExpRatioMin is min(lower limit) of ExpRatio generated by firmware.
                                            When enExpRatioType is OP_TYPE_MANUAL, u32ExpRatioMin is invalid. */
    MBP_U16 u16Tolerance;            /*RW; Range:[0x0, 0xFF]; Format:8.0;et the dynamic range tolerance. Format: unsigned 6.2-bit fixed-point. 0x4 means 1dB. */
    MBP_U16 u16Speed;                /*RW; Range:[0x0, 0xFF]; Format:8.0; exposure ratio adjust speed */
    MBP_U16 u16RatioBias;            /*RW; Range:[0x0, 0xFFFF]; Format:16.0; exposure ratio bias */

} ISP_WDR_EXPOSURE_ATTR_T;

typedef struct _ISP_HDR_EXPOSURE_ATTR_T
{
    ISP_OP_TYPE_E enExpHDRLvType;   /*RW; Range:[0, 1]; Format:1.0; OP_TYPE_AUTO: The ExpHDRLv used in ISP is generated by firmware; OP_TYPE_MANUAL: The ExpHDRLv used in ISP is set by u32ExpHDRLv */
    MBP_U32 u32ExpHDRLv;             /*RW; Range:[0x40, 0x400]; Format:26.6; 0x40 means 1 times.
                                            When enExpHDRLvType is OP_TYPE_AUTO, u32ExpHDRLv is invalid.
                                            When enExpHDRLvType is OP_TYPE_MANUAL, u32ExpHDRLv is the quotient of exposure / linear exposure. */
    MBP_U32 u32ExpHDRLvMax;          /*RW; Range:[0x40, 0x400]; Format:26.6; 0x40 means 1 times.
                                            When enExpHDRLvType is OP_TYPE_AUTO, u32ExpHDRLvMax is max(upper limit) of ExpHDRLv generated by firmware.
                                            When enExpHDRLvType is OP_TYPE_MANUAL, u32ExpHDRLvMax is invalid. */
    MBP_U32 u32ExpHDRLvMin;          /*RW; Range:[0x40, 0x400]; Format:26.6; limited range:[0x40, u32ExpHDRLvMax],0x40 means 1 times.
                                            When enExpHDRLvType is OP_TYPE_AUTO, u32ExpHDRLvMin is min(lower limit) of ExpHDRLv generated by firmware.
                                            When enExpHDRLvType is OP_TYPE_MANUAL, u32ExpHDRLvMin is invalid. */
    MBP_U32 u32ExpHDRLvWeight;       /*RW; Range:[0x0, 0x400]; Format:16.0; exposure HDR level weight. */

} ISP_HDR_EXPOSURE_ATTR_T;

typedef struct _ISP_AE_ROUTE_EX_T
{
    MBP_U32 u32TotalNum;
    MBP_S32 astRouteExNode[33];
} ISP_AE_ROUTE_EX_T;

typedef struct _ISP_AE_ROI_T {
    MBP_U32 enAeRoi;            /**< u1, AE ROI0 work mode. 0:off 1:on */
    MBP_U32 u32Weight;           /**< u4, ROI0 zone exposure weight */
    MBP_U32 u32XStart;          /**< u14, ROI0 rectangle zone start position x  */
    MBP_U32 u32YStart;          /**< u14, ROI0 rectangle zone start position y  */
    MBP_U32 u32Width;         /**< u14, ROI0 rectangle zone width  */
    MBP_U32 u32Height;        /**< u14, ROI0 rectangle zone height */
    MBP_U32 u32RoiTarget;
} ISP_AE_ROI_T;

typedef struct _ISP_AE_ROI_ATTR_T
{
    ISP_AE_ROI_T stAeRoi[16];
} ISP_AE_ROI_ATTR_T;

/********************* AWB structs ************************/
/*
Defines the AWB online calibration type
u16AvgRgain: the avg value of Rgain after online calibration
u16AvgBgain: the avg value of Bgain after online calibration
*/
typedef struct _ISP_AWB_Calibration_Gain_T
{
    MBP_U16 u16AvgRgain;
    MBP_U16 u16AvgBgain;
} ISP_AWB_Calibration_Gain_T;

/*
Defines the AWB policy in the multi-illuminant scenario
0 = Automatic saturation adjustment in the multi-illuminant scenario
1 = Automatic ccm adjustment in the multi-illuminant scenario
*/
typedef enum _ISP_AWB_MULTI_LS_TYPE_E
{
    AWB_MULTI_LS_SAT = 0,
    AWB_MULTI_LS_CCM = 1,
    AWB_MULTI_LS_BUTT
} ISP_AWB_MULTI_LS_TYPE_E;

typedef enum _ISP_AWB_INDOOR_OUTDOOR_STATUS_E
{
    AWB_INDOOR_MODE = 0,
    AWB_OUTDOOR_MODE = 1,
    AWB_INDOOR_OUTDOOR_BUTT
} ISP_AWB_INDOOR_OUTDOOR_STATUS_E;


#define AWB_LS_NUM          (4)
#define AWB_MULTI_CT_NUM    (8)
/*extended AWB attributes*/
typedef struct _ISP_AWB_ATTR_EX_T
{
    MBP_S16 s16AwbRgPos[15];
    MBP_S16 s16AwbBgPos[15];
    MBP_S16 s16AwbMeshDisTab[225];
} ISP_AWB_ATTR_EX_T;

typedef enum _ISP_AWB_MAN_MODE_E
{
    ISP_AWB_MODE_GAIN         = 0,
    ISP_AWB_MODE_COLOR_TEM    = 1,
    ISP_AWB_MODE_MAX
} ISP_AWB_MAN_MODE_E;


#define AWB_CURVE_PARA_NUM        (6)
typedef struct _ISP_AWB_ATTR_T
{
    ISP_AWB_MAN_MODE_E enManMode;
    MBP_U32 u32ConvgcSpeed;
    ISP_STRATEGY_E u32MixCtMode;
    MBP_U32 u32CoverRange;
    MBP_BOOL_E bEnCustomGrayZone;
    MBP_BOOL_E bEnAwbCtDynCvrng;    /**< u1, color temperature dynamic cover range enable */
    MBP_BOOL_E bEnAwbCtLumaWgt;     /**< u1, color temperature luma weighted calculation enable by luma value of local block */
    MBP_BOOL_E bEnAwbCtWgt;          /**< u1, color temperature luma weighted calculation enable */
    MBP_BOOL_E bEnAwbCtAdj;          /**< u1, color temperature adjust enable */
} ISP_AWB_ATTR_T;

typedef struct  _ISP_SPECAWB_CAA_CONTROl_T
{
    MBP_S16 s16AwbMeshCtTab[225];
    MBP_S32 s32AwbCtRgCurve[4];
    MBP_S32 s32AwbCtBgCurve[4];
} ISP_CAA_CONTROl_T;

typedef struct _ISP_MWB_ATTR_T
{
    MBP_U32 u32ManualRGain;
    MBP_U32 u32ManualBGain;
    MBP_U32 u32ManualTemperature;
    MBP_BOOL_E bEnAwbWin;
    MBP_U32 u32Hst;
    MBP_U32 u32Hsize;
    MBP_U32 u32Vst;
    MBP_U32 u32Vsize;
} ISP_MWB_ATTR_T;

typedef struct _ISP_WB_ATTR_T
{
    MBP_BOOL_E bByPass;              /*RW; Range: [0, 1];  Format:1.0; If enabled, awb will be bypassed*/
    ISP_MWB_ATTR_T  stManual;
    ISP_AWB_ATTR_T  stAuto;
} ISP_WB_ATTR_T;

typedef struct _ISP_SATURATION_MANUAL_T {
    MBP_S32   s32Sat;
    MBP_S32   s32Coef[CCM_MATRIX_SIZE];
} ISP_SATURATION_MANUAL_T;

typedef struct _ISP_SATURATION_LUT_T {
    MBP_S32 s32Sat[CCM_ADJ_SIZE];
} ISP_SATURATION_LUT_T;

typedef struct _ISP_SATURATION_COEF_T {
    MBP_S32 au32SatCoef[CCM_ADJ_SIZE];
} ISP_SATURATION_COEF_T;

typedef struct _ISP_SATURATION_COEF_LUT_T {
    MBP_S32                s32Size;
    ISP_SATURATION_COEF_T  au32SatLut[20];
} ISP_SATURATION_COEF_LUT_T;

typedef struct _ISP_SATURATION_AUTO_T {
    ISP_SATURATION_LUT_T        au32Sat;
    ISP_SATURATION_COEF_LUT_T   au32SatLut;
} ISP_SATURATION_AUTO_T;

typedef struct _ISP_SATURATION_ATTR_T {
    ISP_OP_TYPE_E enOpType;
    ISP_SATURATION_MANUAL_T stManual;
    ISP_SATURATION_AUTO_T stAuto;
} ISP_SATURATION_ATTR_T;

typedef struct _ISP_COLORMATRIX_MANUAL_T {
    MBP_S32   s32Sat;
    MBP_S32   s32Coef[CCM_MATRIX_SIZE];
} ISP_COLORMATRIX_MANUAL_T;

typedef struct _ISP_COLORMATRIX_AUTO_T {
    ISP_SATURATION_LUT_T        au32Sat;
    ISP_SATURATION_COEF_LUT_T   au32SatLut;
} ISP_COLORMATRIX_AUTO_T;

typedef struct _ISP_COLORMATRIX_ATTR_T {
    ISP_OP_TYPE_E enOpType;
    ISP_COLORMATRIX_MANUAL_T stManual;
    ISP_COLORMATRIX_AUTO_T stAuto;
} ISP_COLORMATRIX_ATTR_T;

typedef struct _ISP_WB_INFO_T
{
    MBP_U16 u16Rgain;
    MBP_U16 u16Grgain;
    MBP_U16 u16Gbgain;
    MBP_U16 u16Bgain;
    MBP_U16 u16Saturation;
    MBP_U16 u16ColorTemp;
    MBP_U16 u16ColorTempDiff;
    MBP_S32 as32CCM[CCM_MATRIX_SIZE];
    MBP_U16 u16RgnRgain;
    MBP_U16 u16RgnBgain;
} ISP_WB_INFO_T;

typedef struct {
    MBP_U32 u32Pack0;
    MBP_U32 u32Pack1;
} ISP_WB_PACK_T;

typedef struct _ISP_WB_STATS_T
{
    ISP_WB_PACK_T stData[4*32*24];
    MBP_U32 u32ZonesNum;
} ISP_WB_STATS_T;

/********************* AF structs ************************/

typedef struct _ISP_AF_ATTR_T
{
    MBP_S32 s32DistanceMax; /* RW;the focus range */
    MBP_S32 s32DistanceMin;
    MBP_U8 u8Weight[AF_ZONE_ROW][AF_ZONE_COLUMN];/* RW;weighting table */
} ISP_AF_ATTR_T;
typedef struct _ISP_MF_ATTR_T
{
    MBP_S32 s32DefaultSpeed;     /* RW;1,default speed(unit:m/s).(onvif)*/
} ISP_MF_ATTR_T;
typedef struct _ISP_FOCUS_ATTR_T
{
    ISP_OP_TYPE_E  enOpType;
    ISP_MF_ATTR_T  stManual;
    ISP_AF_ATTR_T  stAuto;
} ISP_FOCUS_ATTR_T;

typedef struct _ISP_CALCFLICKER_INPUT_T {
    MBP_U32 u32ValidSel;
    MBP_U32 u32AvgChnenMod;
    MBP_U32 u32Lpf;
    MBP_U32 u32CntThd;
    MBP_U32 u32StatPkDisThr;
    MBP_U32 u32StatPkValThr;
    MBP_U32 u32StatPkValDiffThr;
    MBP_U32 u32FftNlen;
    MBP_U32 u32FftMlen;
    MBP_U32 u32FftNorm;
    MBP_U32 u32FftValidThrd;
    MBP_U32 u32SnsExpInfoAdjGain;
    MBP_U32 u32FlkrDetJdgRatio;
    MBP_U32 u32FlkrDetSumPdifTh;
    MBP_U32 u32FlkrDetScanOfst;
    MBP_U32 u32FlkrDetWaveOfst;
    MBP_U32 u32FlkrDetAeDiffTh;
    MBP_U32 u32FlkrDetNoFlkrCntTh;
    MBP_U32 u32FlkrDetPdifRatio;
} ISP_CALCFLICKER_INPUT_T;

typedef struct _ISP_CALCFLICKER_OUTPUT_T {
    MBP_U32 u32DetFftFlag;
    MBP_U32 u32Det50Hz;
    MBP_U32 u32DetCnt;
    MBP_U32 u32DetR50;
    MBP_U32 u32DetR60;
} ISP_CALCFLICKER_OUTPUT_T;

typedef struct _ISP_SENSOR_REG_T {
    MBP_S32 s32Addr;
    MBP_S32 s32Data;
} ISP_SENSOR_REG_T;

#pragma pack()

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* __AML_COMM_ISP_H__ */
