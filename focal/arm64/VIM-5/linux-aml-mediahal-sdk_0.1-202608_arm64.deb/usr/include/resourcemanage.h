/*
 * Copyright (c) 2019 Amlogic, Inc. All rights reserved.
 *
 * This source code is subject to the terms and conditions defined in the
 * file 'LICENSE' which is part of this source code package.
 *
 * Description:
 */

#ifndef _RESOURCE_MANAGE_H_
#define _RESOURCE_MANAGE_H_

#ifdef  __cplusplus
extern "C" {
#endif

#include <sys/ioctl.h>
#include <stdint.h>

typedef uint32_t __u32;
typedef int32_t  __s32;

#define    RESMAN_IOC_MAGIC  'R'

#define    RESMAN_IOC_QUERY_RES              _IOR(RESMAN_IOC_MAGIC, 0x01, int)
#define    RESMAN_IOC_ACQUIRE_RES            _IOW(RESMAN_IOC_MAGIC, 0x02, int)
#define    RESMAN_IOC_RELEASE_RES            _IOR(RESMAN_IOC_MAGIC, 0x03, int)
#define    RESMAN_IOC_SET_APPINFO            _IOW(RESMAN_IOC_MAGIC, 0x04, int)
#define    RESMAN_IOC_SUPPORT_RES            _IOR(RESMAN_IOC_MAGIC, 0x05, int)
#define    RESMAN_IOC_RELEASE_ALL            _IOR(RESMAN_IOC_MAGIC, 0x06, int)
#define    RESMAN_IOC_LOAD_RES               _IOR(RESMAN_IOC_MAGIC, 0x07, int)
#define    RESMAN_IOC_GET_SYS_DEBUG_LEVEL    _IOR(RESMAN_IOC_MAGIC, 0x08, int)
#define    RESMAN_IOC_SET_SYS_DEBUG_LEVEL    _IOR(RESMAN_IOC_MAGIC, 0x09, int)
#define    RESMAN_IOC_GET_ERROR_INFO         _IOR(RESMAN_IOC_MAGIC, 0x0A, int)
#define    RESMAN_IOC_GET_COUNTER_INDEX      _IOR(RESMAN_IOC_MAGIC, 0x0B, int)

#define    RESMAN_SUPPORT_PREEMPT        1
#define    RESITEMSIZE             (32)

struct resman_para {
    __u32 k;
    union {
        struct {
            __u32 preempt;
            __u32 timeout;
            char arg[32];
        } acquire;
        struct {
            char name[32];
            __u32 type;
            __s32 value;
            __s32 avail;
            char app_name[32]; // appname that acquired this resource
        } query;
        struct {
            char name[32];
        } support;
    } v;
};

struct app_info {
    char appname[32];
    __u32  apptype;
    int   prio ;
};

struct res_item {
    char name[32];
    __u32 type;
    char arg[32];
};

enum RESMAN_ID {
    RESMAN_ID_VFM_DEFAULT,
    RESMAN_ID_AMVIDEO,
    RESMAN_ID_PIP_VIDEO,
    RESMAN_ID_SEC_TVP,
    RESMAN_ID_TSPARSER,
    RESMAN_ID_CODEC_MM,
    RESMAN_ID_ADC_PLL,
    RESMAN_ID_DECODER,
    RESMAN_ID_DMX,
    RESMAN_ID_DI,
    RESMAN_ID_HWC,
    RESMAN_ID_VDETE,
    RESMAN_ID_VDPLANE,
    RESMAN_ID_AUDIO_DECODER,
    RESMAN_ID_MAX,
};

enum RESMAN_TYPE {
    RESMAN_TYPE_COUNTER = 1,
    RESMAN_TYPE_TOGGLE,
    RESMAN_TYPE_TVP,
    RESMAN_TYPE_CODEC_MM,
    RESMAN_TYPE_CAPACITY_SIZE
};

enum RESMAN_APP {
    RESMAN_APP_NONE = -1,
    RESMAN_APP_OMX  = 0,
    RESMAN_APP_XDVB,
    RESMAN_APP_HDMI_IN,
    RESMAN_APP_SEC_TVP,
    RESMAN_APP_DVBKIT,
    RESMAN_APP_TSPLAYER,
    RESMAN_APP_CODEC2,
    RESMAN_APP_DEBUG_SERVER,
    RESMAN_APP_OTHER    = 10,
    RESMAN_APP_SYSTEM_RESERVED = 100,
    RESMAN_APP_DIAGNOSTICS = 101,
    RESMAN_APP_GST = 200,
};

enum RESMAN_EVENT {
    RESMAN_EVENT_REGISTER				= 0x1000,
    RESMAN_EVENT_UNREGISTER				= 0x1001,
    RESMAN_EVENT_PREEMPT				= 0x1002,
    RESMAN_EVENT_STOP					= 0x1003,
    RESMAN_EVENT_RESREPORT				= 0x1004,
    RESMAN_EVENT_DEBUGEVENT				= 0x1005,
    RESMAN_EVENT_REGISTER_CALLBACK		= 0x1006
};

bool resman_support(void);
int resman_init(const char *appName, int appType);
int resman_init_ext(const char *appName, int appType, int prio);
int resman_close(int handle);
int resman_setappinfo(int handle, struct app_info *appInfo);
bool resman_acquire_para(int handle, int resId, const unsigned int time_out,
    int preempt, const char *arg);//Timeout unit: milliseconds
bool resman_acquire(int handle, int resId);
bool resman_acquire_para_ext(int handle, const char *resName,
    const unsigned int timeOut, int preempt, const char *arg);
int resman_release(int handle, int resId);
int resman_release_ext(int handle, const char * resName);
int resman_release_all(int handle);
int resman_query(int handle, struct resman_para *resStatus);
int resman_query_ext(int handle, struct resman_para *resStatus,
    const char * resName);
bool resman_acquire_wait(int handle, int resId,
    const unsigned int timeOut);//Timeout unit: milliseconds
int resman_get_counter_res_index(int handle, int resId);
bool resman_resource_support(const char* resName);
int resman_register(int fd, void (* handler)(void *), void *opaque);
void resman_unregister(int fd);
void resman_stop_thread();
int resman_estimate_size(int format, unsigned int width, unsigned int height);
int resman_load_res(int handle, const char *name, __u32 resId, const char *arg);
int resman_add_handler_and_resreports(int fd, void (* handler)(void *),
                                      void (* report)(void *), void *opaque);
int resman_add_debug_callback(int fd,
                              void (* debug)(void *, const char *, int), void *opaque);
#ifdef  __cplusplus
}
#endif

#endif /** _RESOURCE_MANAGE_H_ **/
