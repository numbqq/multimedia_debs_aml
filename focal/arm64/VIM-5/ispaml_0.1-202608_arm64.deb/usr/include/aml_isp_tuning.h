/*
 * Copyright (c) 2021 Amlogic, Inc. All rights reserved.
 *
 * This source code is subject to the terms and conditions defined in the
 * file 'LICENSE' which is part of this source code package.
 *
 * Description:
 */


#ifndef __AML_ISP_TUNING_H__
#define __AML_ISP_TUNING_H__

#include <stdint.h>

#define ISO_NUM_MAX     (10)
#define RATIO_NUM_MAX     (8)


typedef enum CALIBRATION_TYPE {
    CALIBRATION_TOP_CTL                   ,
    CALIBRATION_FMT_CTL                   ,
    CALIBRATION_RES_CTL                   ,
    CALIBRATION_AWB_CTL                   ,
    CALIBRATION_AWB_CT_POS                ,
    CALIBRATION_AWB_CT_RG_COMPENSATE       ,
    CALIBRATION_AWB_CT_BG_COMPENSATE       ,
    CALIBRATION_AWB_CT_WGT                ,
    CALIBRATION_AWB_CT_DYN_CVRANGE        ,
    CALIBRATION_AWB_WEIGHT_H              ,
    CALIBRATION_AWB_WEIGHT_V              ,
    CALIBRATION_AE_CTL                    ,
    CALIBRATION_AE_CORR_LUT               ,
    CALIBRATION_AE_CORR_POS_LUT           ,
    CALIBRATION_AE_ROUTE                  ,
    CALIBRATION_AE_WEIGHT_H               ,
    CALIBRATION_AE_WEIGHT_V               ,
    CALIBRATION_AE_WEIGHT_T               ,
    CALIBRATION_DAYNIGHT_DETECT           ,
    CALIBRATION_DAYNIGHT_RG_BG            ,
    CALIBRATION_HIGHLIGHT_DETECT           ,
    CALIBRATION_AF_CTL                    ,
    CALIBRATION_AF_WEIGHT_H               ,
    CALIBRATION_AF_WEIGHT_V               ,
    CALIBRATION_FLICKER_CTL               ,
    CALIBRATION_GTM                       ,
    CALIBRATION_GE_ADJ                    ,
    CALIBRATION_GE_S_ADJ                  ,
    CALIBRATION_DPC_CTL                   ,
    CALIBRATION_DPC_S_CTL                 ,
    CALIBRATION_DPC_ADJ                   ,
    CALIBRATION_DPC_S_ADJ                 ,
    CALIBRATION_WDR_CTL                   ,
    CALIBRATION_WDR_MD_DET_ADJ            ,
    CALIBRATION_WDR_MD_DECI_ADJ           ,
    CALIBRATION_WDR_FORCE_SHORT_ADJ       ,
    CALIBRATION_WDR_FORCE_LONG_ADJ        ,
    CALIBRATION_WDR_NR_ADJ                ,
    CALIBRATION_WDR_DTL_ADJ               ,
    CALIBRATION_WDR_DESAT_ADJ             ,
    CALIBRATION_WDR_DPF_ADJ               ,
    CALIBRATION_WDR_DESAT_BY_LUMA_LUT_LOW ,
    CALIBRATION_WDR_DESAT_BY_SAT_LUT_LOW  ,
    CALIBRATION_WDR_DPF_BY_SAT_LUT_LOW    ,
    CALIBRATION_WDR_CORING_LUT_LOW        ,
    CALIBRATION_WDR_DESAT_BY_LUMA_LUT_MID ,
    CALIBRATION_WDR_DESAT_BY_SAT_LUT_MID  ,
    CALIBRATION_WDR_DPF_BY_SAT_LUT_MID    ,
    CALIBRATION_WDR_CORING_LUT_MID        ,
    CALIBRATION_WDR_DESAT_BY_LUMA_LUT_MID1,
    CALIBRATION_WDR_DESAT_BY_SAT_LUT_MID1 ,
    CALIBRATION_WDR_DPF_BY_SAT_LUT_MID1   ,
    CALIBRATION_WDR_CORING_LUT_MID1       ,
    CALIBRATION_WDR_DESAT_BY_LUMA_LUT_HIGH,
    CALIBRATION_WDR_DESAT_BY_SAT_LUT_HIGH ,
    CALIBRATION_WDR_DPF_BY_SAT_LUT_HIGH   ,
    CALIBRATION_WDR_CORING_LUT_HIGH       ,
    CALIBRATION_SQRT_EOTF_CTL            ,
    CALIBRATION_SQRT_EOTF_OFST            ,
    CALIBRATION_OE_EOTF                   ,
    CALIBRATION_SQRT1                     ,
    CALIBRATION_EOTF1                     ,
    CALIBRATION_RAWSNR_ADJ                ,
    CALIBRATION_RAWSNR_BLD_LUMA_GAIN      ,
    CALIBRATION_RAWSNR_SIGMA_WT      ,
    CALIBRATION_RAWTNR_CTL                ,
    CALIBRATION_RAWTNR_ADJ                ,
    CALIBRATION_RAWTNR_SAD2ALPHA_LUT_COARSE   ,
    CALIBRATION_RAWTNR_SAD2ALPHA_LUT_FINE   ,
    CALIBRATION_RAWTSNR_SNR_ALPHA_LUT     ,
    CALIBRATION_RAWTSNR_MN_LUT_16X       ,
    CALIBRATION_RAWTSNR_MN_LUT_1X        ,
    CALIBRATION_COMPRESS_RATIO            ,
    CALIBRATION_LENS_SHADING_ADJ          ,
    CALIBRATION_ADP_LENS_SHADING_CTL      ,
    CALIBRATION_LENS_SHADING_CT_CORRECT   ,
    CALIBRATION_LENS_SHADING_ADP          ,
    CALIBRATION_DMS_ADJ                   ,
    CALIBRATION_DMS_CTL                   ,
    CALIBRATION_PFR_CTL                   ,
    CALIBRATION_PFR_SAT_WT_LUT            ,
    CALIBRATION_PFR_RG_DIFF_WT_LUT        ,
    CALIBRATION_CCM_ADJ                   ,
    CALIBRATION_CCM_SAT_DW_VIA_SAT        ,
    CALIBRATION_CCM_SAT_DW_VIA_LUMA       ,
    CALIBRATION_LUT3D_ADJ                 ,
    CALIBRATION_LTM_CTL                   ,
    CALIBRATION_LTM_LO_HI_GM              ,
    CALIBRATION_LTM_APH_BETA              ,
    CALIBRATION_LTM_CONTRAST              ,
    CALIBRATION_LTM_SHARP_ADJ             ,
    CALIBRATION_LTM_SATUR_LUT             ,
    CALIBRATION_LC_CTL                    ,
    CALIBRATION_LC_STRENGTH               ,
    CALIBRATION_LC_SATUR_LUT              ,
    CALIBRATION_DNLP_CTL                  ,
    CALIBRATION_DNLP_STRENGTH             ,
    CALIBRATION_DNLP_BLK_WHT_EXT          ,
    CALIBRATION_DNLP_SCURV_LOW            ,
    CALIBRATION_DNLP_SCURV_MID1           ,
    CALIBRATION_DNLP_SCURV_MID2           ,
    CALIBRATION_DNLP_SCURV_HGH1           ,
    CALIBRATION_DNLP_SCURV_HGH2           ,
    CALIBRATION_DHZ_CTL                   ,
    CALIBRATION_DHZ_STRENGTH              ,
    CALIBRATION_PEAKING_CTL               ,
    CALIBRATION_PEAKING_ADJUST            ,
    CALIBRATION_PEAKING_FLT1_MOTION_ADP_GAIN,
    CALIBRATION_PEAKING_FLT2_MOTION_ADP_GAIN,
    CALIBRATION_PEAKING_GAIN_VS_LUMA_LUT  ,
    PEAKING_COLOR_PRTC_UV_ST     ,
    CALIBRATION_PEAKING_OS_UP_VIA_ALP     ,
    CALIBRATION_PEAKING_OS_DW_VIA_ALP     ,
    CALIBRATION_PEAKING_CIR_GAIN          ,
    CALIBRATION_PEAKING_DRT_GAIN          ,
    CALIBRATION_PEAKING_CIR_W_GAIN          ,
    CALIBRATION_PEAKING_DRT_W_GAIN          ,
    CALIBRATION_CM_CTL                    ,
    CALIBRATION_CM_SATGLBGAIN_VIA_Y       ,
    CALIBRATION_CM_SATGLBGAIN_VIA_SAT     ,
    CALIBRATION_CM_SATGLBGAIN_VIA_HUE       ,
    CALIBRATION_CM_HUE_ADJ_VIA_HUE          ,
    CALIBRATION_HLC_CTL                   ,
    CALIBRATION_BLACK_LEVEL               ,
    CALIBRATION_MESH_BLACK_LEVEL          ,
    CALIBRATION_SHADING_RADIAL_R          ,
    CALIBRATION_SHADING_RADIAL_G          ,
    CALIBRATION_SHADING_RADIAL_B          ,
    CALIBRATION_LENS_OTP_CENTER_OFFSET    ,
    CALIBRATION_SHADING_LS_D65_R          ,
    CALIBRATION_SHADING_LS_D65_B          ,
    CALIBRATION_SHADING_LS_D65_G          ,
    CALIBRATION_SHADING_LS_CWF_R          ,
    CALIBRATION_SHADING_LS_CWF_B          ,
    CALIBRATION_SHADING_LS_CWF_G          ,
    CALIBRATION_SHADING_LS_TL84_R         ,
    CALIBRATION_SHADING_LS_TL84_G         ,
    CALIBRATION_SHADING_LS_TL84_B         ,
    CALIBRATION_SHADING_LS_A_R            ,
    CALIBRATION_SHADING_LS_A_G            ,
    CALIBRATION_SHADING_LS_A_B            ,
    CALIBRATION_LENS_SHADING_CTL          ,
    CALIBRATION_GAMMA                     ,
    CALIBRATION_CCM                       ,
    CALIBRATION_CAC_CTL                   ,
    CALIBRATION_AWB_RG_POS                ,
    CALIBRATION_AWB_BG_POS                ,
    CALIBRATION_AWB_MESH_DIST_TAB         ,
    CALIBRATION_AWB_MESH_CT_TAB           ,
    CALIBRATION_AWB_CT_RG_CURVE           ,
    CALIBRATION_AWB_CT_BG_CURVE           ,
    CALIBRATION_AWB_WB_GOLDEN_D50         ,
    CALIBRATION_AWB_WB_OTP_D50            ,
    CALIBRATION_NOISE_PROFILE             ,
    CALIBRATION_LTM_HIST_BLK65            ,
    CALIBRATION_DNLP_ADP_THRD             ,
    CALIBRATION_DNLP_BLK_BOOST            ,
    CALIBRATION_DNLP_GAIN_VAR_LUT49       ,
    CALIBRATION_DNLP_WEXT_GAIN            ,
    CALIBRATION_DNLP_ADP_OFSET            ,
    CALIBRATION_DNLP_MONO_PROTECT         ,
    CALIBRATION_DNLP_TREND_WHT_EXPAND_LUT8,
    CALIBRATION_DHZ_SKY_PROT_LUT          ,
    CALIBRATION_PPS_SCALE_8TAP               ,
    CALIBRATION_PPS_SCALE_4TAP               ,
    CALIBRATION_PPS_SCALE_2TAP               ,
    CALIBRATION_DYM_CUSTOM_SETTING        ,
    CALIBRATION_AWB_PRESET                ,
    //ISP C5

    CALIBRATION_YUVTNR_CTL                ,
    CALIBRATION_YUVTNR_ADJ                ,
    CALIBRATION_YUVTNR_MN_SAD2ALPHA_FINE          ,
    CALIBRATION_YUVTNR_MN_SAD2ALPHA_COARSE     ,
    CALIBRATION_YUVTNR_MN_SAD_THN_COARSE   ,
    CALIBRATION_YUVTNR_PRO_SAD_THN_COARSE        ,
    CALIBRATION_YUVTNR_PRO_SAD2ALPHA_COARSE      ,
    CALIBRATION_YUVTNR_IIR_ALPHA_LUMA_GAIN   ,
    CALIBRATION_YUVTNR_IIR_ALPHA_VAR_DIFF_GAIN   ,
    CALIBRATION_YUVTNR_PRO_SAD_COR_LUT           ,
    CALIBRATION_YUVTNR_PRO_SAD_DIFF_GAIN           ,
    CALIBRATION_YUVTNR_MN_COARSE_SAD_COR_LUT           ,
    CALIBRATION_YUVTNR_MN_FINE_SAD_COR_LUT           ,
    CALIBRATION_YUVTNR_MN_FINE_COR_VAR_GAIN           ,
    CALIBRATION_YUVTNR_MN_MAX_GRAD_DIFF_GAIN    ,
    CALIBRATION_YUVTNR_MN_VAR_DIFF_GAIN    ,
    CALIBRATION_YUVTNR_PRO_VAR_DIFF_GAIN    ,
    CALIBRATION_YUVTNR_MN_FINE_DIFF_GAIN    ,
    CALIBRATION_YUVTNR_ALPHA2META_TH,
    CALIBRATION_YUVSNR_NLEL_LUT,
    CALIBRATION_YUVSNR_ADJ                ,
    CALIBRATION_YUVSNR_WT_GAIN            ,
    CALIBRATION_YUVSNR_COR_META2ALPHA      ,
    CALIBRATION_YUVSNR_PDPC_CTL           ,
    CALIBRATION_YUVSNR_PDPC_THRD           ,
    CALIBRATION_YUVSNR_WT_META2ALPHA       ,
    CALIBRATION_YUVSNR_C_ADJ               ,
    CALIBRATION_YUVSNR_C_SAD_META2ALPHA    ,
    CALIBRATION_LUMA_CLIP                 ,
    CALIBRATION_AWB_REF_REMOVE_LUT        ,
    CALIBRATION_RAWSNR_CTL                   ,
    CALIBRATION_AWB_EXT_CTL,
    CALIBRATION_AWB_V2_CTL,
    CALIBRATION_AWB_CLUST_CTL,
    CALIBRATION_AWB_ADV_CT_POS,
    CALIBRATION_AWB_ADV_CT_DYN_CVRANGE,
    CALIBRATION_AWB_ADV_CT_WGT,
    CALIBRATION_AWB_DIST_WGT,
    CALIBRATION_AWB_MISLEAD,
    CALIBRATION_AWB_LOCK_TOLER,
    CALIBRATION_AWB_ADV_CT_RG_COMPENSATE,
    CALIBRATION_AWB_ADV_CT_BG_COMPENSATE,
    CALIBRATION_AWB_REFCOLOR,

    CALIBRATION_VERSION                ,
    CALIBRATION_CSC_CTL                  ,
    CALIBRATION_AFC_CTL                  ,
    CALIBRATION_TOTAL_SIZE                ,
} CALIBRATION_TYPE_E;

#define CALIBRATION_LENS_SHADING_ACTL CALIBRATION_ADP_LENS_SHADING_CTL

typedef enum
{
    AML_MBI_ISP_BaseAttr= 0x0,
    AML_MBI_ISP_CSCAttr,
    AML_MBI_ISP_ModuleCtrlAttr,
    AML_MBI_ISP_HLCAttr,
    AML_MBI_ISP_PstGammaAttr,
    AML_MBI_ISP_RgbGammaAttr,
    AML_MBI_ISP_ShadingLutAttr,
    AML_MBI_ISP_RadialShadingLut,
    AML_MBI_ISP_FPNRLut,
    AML_MBI_ISP_DrcAttr,
    AISP_BASE_MAX,

    AML_MBI_ISP_ExposureAttr = 40,
    AML_MBI_ISP_WDRExposureAttr,
    AML_MBI_ISP_WBAttr,
    AML_MBI_ISP_AePstGammaUpdate,
    AML_MBI_ISP_CaControl,
    AML_MBI_ISP_AERouterAttr,
    AML_MBI_ISP_CalcFlickerAttr,
    AML_MBI_ISP_CalcFlickerOutput,
    AML_MBI_ISP_WBExAttr,
    AML_MBI_ISP_QueryWBinfo,
    AML_MBI_ISP_QueryEXPinfo,
    AML_MBI_ISP_IRAttr,
    AML_MBI_ISP_AERoiAttr,
    AML_MBI_ISP_QueryWBStats,
    AML_MBI_ISP_QueryWBObj,
    AML_MBI_ISP_WBCorr,
    AML_MBI_ISP_HighLightAttr,
    AML_MBI_ISP_AfZoom,
    AML_MBI_ISP_Focus_value,
    AISP_3A_MAX,

    AML_MBI_ISP_SaturationAttr = 80,
    AML_MBI_ISP_ShadingAttr,
    AML_MBI_ISP_RadialShadingAttr,
    AML_MBI_ISP_BlackLevelAttr,
    AML_MBI_ISP_ColorMatrixAttr,
    AISP_CORRECTION_MAX,

    AML_MBI_ISP_IspSharpenAttr = 120,
    AML_MBI_ISP_FSWDRAttr,
    AML_MBI_ISP_LtmAlgAttr,
    AML_MBI_ISP_LtmGammaAttr,
    AML_MBI_ISP_DhzAttr,
    AML_MBI_ISP_LdcAttr,
    AML_MBI_ISP_LdcLutAttr,
    AML_MBI_ISP_DNLPAttr,
    AML_MBI_ISP_CM2Attr,
    AISP_ENHANCE_MAX,

    AML_MBI_ISP_RAWCNRAttr = 160,
    AML_MBI_ISP_SNRAttr,
    AML_MBI_ISP_TNRAttr,
    AML_MBI_ISP_CNRAttr,
    AML_MBI_ISP_PURPLEAttr,
    AML_MBI_ISP_DMSAttr,
    AML_MBI_ISP_NPAttr,
    AML_MBI_ISP_CrAttr,
    AML_MBI_ISP_FPNRAttr,
    AML_MBI_ISP_DPCAttr,
    AISP_RESTORATION_MAX,

    AML_MBI_ISP_FMWAttr = 200,
    AML_MBI_ISP_RotAttr,
    AML_MBI_ISP_FpsAttr,
    AML_MBI_ISP_SwitchIq,
    AML_MBI_ISP_CfgAlgFps,
    AML_MBI_ISP_SnsReadReg,
    AML_MBI_ISP_SnsWriteReg,
    AML_MBI_ISP_CamIndex,
    AML_MBI_ISP_FusionDistance,
    AML_MBI_ISP_AIispEnable,
} AISP_CMD_ID_E;

typedef struct LookupTable {
    void *ptr;
    uint16_t rows;
    uint16_t cols;
    uint16_t width;
} LookupTable;

typedef struct _AIspCalibrations {
    LookupTable *pstcalibrations[CALIBRATION_TOTAL_SIZE];
} AIspCalibrations;

typedef struct aisp_calib_info_s {
    LookupTable *calibrations[CALIBRATION_TOTAL_SIZE];
} aisp_calib_info_t;

#define CALIBRATION_PACK(LABEL) static LookupTable HEADER##LABEL = { \
                                    .ptr = LABEL, \
                                    .rows = 1, \
                                    .cols = sizeof(LABEL) / sizeof(LABEL[0]), \
                                    .width = sizeof(LABEL[0]),\
                                    }

#define CALIBRATION_PACK2(LABEL) static LookupTable HEADER##LABEL = { \
                                    .ptr = LABEL, \
                                    .rows = sizeof(LABEL) / sizeof(LABEL[0]), \
                                    .cols = sizeof(LABEL[0]) / sizeof(LABEL[0][0]), \
                                    .width = sizeof(LABEL[0][0]),\
                                    }

#define LOAD_CALIB(HAND, LABEL) (HAND)->calibrations[LABEL] = &(HEADER_##LABEL)
#define FILL_CALIB(HAND, LABEL) if ((HAND)->calibrations[LABEL] == NULL)(HAND)->calibrations[LABEL] = &(HEADER_##LABEL)


/***********************************************
** Function Declaration
***********************************************/
#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif /* __AML_ISP_TUNING_H__ */

