/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note */
/*
 * Copyright (C) 2025 Amlogic, Inc. All rights reserved
 */

#ifndef _UAPI_C4_ISP_CONFIG_H_
#define _UAPI_C4_ISP_CONFIG_H_

#include <linux/types.h>

#ifndef v4l2_fourcc
/*  Four-character-code (FOURCC) */
#define v4l2_fourcc(a, b, c, d)\
	((__u32)(a) | ((__u32)(b) << 8) | ((__u32)(c) << 16) | ((__u32)(d) << 24))
#endif

/* Amlogic C4 ISP5 Parameters */
#define V4L2_META_FMT_C4ISP_PARAMS	v4l2_fourcc('C', '4', 'P', 'M')

/* Amlogic C4 ISP5 Statistics */
#define V4L2_META_FMT_C4ISP_STATS	v4l2_fourcc('C', '4', 'S', 'T')

/*
 * Frames are split into zones of almost equal width and height - a zone is a
 * rectangular tile of a frame. The metering blocks within the ISP collect
 * aggregated statistics per zone.
 */
#define C4_ISP_AE_MAX_ZONES (18 * 15)
#define C4_ISP_AF_MAX_ZONES (17 * 15)
#define C4_ISP_AWB_MAX_ZONES (16 * 24)

/**
 * struct c4_isp_awb_zone_stats - AWB statistics of a zone
 *
 * AWB zone stats is aligned with 8 bytes
 *
 * @rg: the ratio of R / G in a zone
 * @bg: the ratio of B / G in a zone
 * @pixel_sum: the total number of pixels used in a zone
 */
struct c4_isp_awb_zone_stats {
	__u16 rg;
	__u16 bg;
	__u32 pixel_sum;
};

/**
 * struct c3_isp_awb_stats - Auto white balance statistics information.
 *
 * AWB statistical information of all zones.
 *
 * @stats: array of auto white balance statistics
 */
struct c4_isp_awb_stats {
	struct c4_isp_awb_zone_stats stats[C4_ISP_AWB_MAX_ZONES];
	__u32 info[8];
} __attribute__((aligned(16)));

/**
 * struct c4_isp_ae_zone_stats - AE statistics of a zone
 *
 * AE zone stats is aligned with 8 bytes.
 * This is a 5-bin histogram and the total sum is normalized to 0xffff.
 * So hist2 = 0xffff - (hist0 + hist1 + hist3 + hist4)
 *
 * @hist0: the global normalized pixel count for bin 0
 * @hist1: the global normalized pixel count for bin 1
 * @hist3: the global normalized pixel count for bin 3
 * @hist4: the global normalized pixel count for bin 4
 */
struct c4_isp_ae_zone_stats {
	__u16 hist0;
	__u16 hist1;
	__u16 hist3;
	__u16 hist4;
};

/**
 * struct c4_isp_ae_stats - Exposure statistics information
 *
 * AE statistical information consists of all blocks information and a 1024-bin
 * histogram.
 *
 * @stats: array of auto exposure block statistics
 * @reserved: undefined buffer space
 * @hist: a 1024-bin histogram for the entire image
 */
struct c4_isp_ae_stats {
	struct c4_isp_ae_zone_stats stats[C4_ISP_AE_MAX_ZONES];
	__u32 info[12];
	__u32 hist[256];
} __attribute__((aligned(16)));

/**
 * struct c4_isp_af_zone_stats - AF statistics of a zone
 *
 * AF zone stats is aligned with 8 bytes.
 * The zonal accumulated contrast metrics are stored in floating point format
 * with 16 bits mantissa and 5 or 6 bits exponent. Apart from contrast metrics
 * we accumulate squared image and quartic image data over the zone.
 *
 * @i2_mat: the mantissa of zonal squared image pixel sum
 * @i4_mat: the mantissa of zonal quartic image pixel sum
 * @e4_mat: the mantissa of zonal multi-directional quartic edge sum
 * @e4_exp: the exponent of zonal multi-directional quartic edge sum
 * @i2_exp: the exponent of zonal squared image pixel sum
 * @i4_exp: the exponent of zonal quartic image pixel sum
 */
struct c4_isp_af_zone_stats {
	__u16 i2_mat;
	__u16 i4_mat;
	__u16 c4_mat0;
	__u16 c4_exp0 : 5;
	__u16 i2_exp0 : 5;
	__u16 i4_exp0 : 6;
	__u16 c4_mat1;
	__u16 c4_exp1 : 5;
	__u16 i2_exp1 : 5;
	__u16 i4_exp1 : 6;
	__u16 c4_mat2;
	__u16 c4_exp2 : 5;
	__u16 i2_exp2 : 5;
	__u16 i4_exp2 : 6;
};

/**
 * struct c4_isp_af_stats - Auto Focus statistics information
 *
 * AF statistical information of each zone
 *
 * @stats: array of auto focus block statistics
 * @reserved: undefined buffer space
 */
struct c4_isp_af_stats {
	struct c4_isp_af_zone_stats stats[C4_ISP_AF_MAX_ZONES];
	__u32 glb[20];
} __attribute__((aligned(16)));


struct c4_isp_flkr_stats {
	__u32 avg_dif[5120];
} __attribute__((aligned(16)));

struct c4_isp_post_stats {
	__u32 blk_stats[2048];
	__u32 glb_stats[256];
	__u32 dnlp_stats[64];
} __attribute__((aligned(16)));

/**
 * struct c4_isp_stats_info - V4L2_META_FMT_C3ISP_STATS
 *
 * Contains ISP statistics
 *
 * @awb: auto white balance stats
 * @ae: auto exposure stats
 * @af: auto focus stats
 */

typedef struct top_req_info_s {
    __u32 raw_mode;
	__u32 glbpixwgt;
} top_req_info_t;

typedef struct wdr_req_info_s {
	__u16 expcomb_blend_thd[2];
	__u32 ro_wdr_unsat_cnt;
	__u32 ro_wdr_unsat_sum[2];
	__u16 ro_wdr_mv_ovsat_blkmax_cnt;
	__u16 ro_wdr_still_flag;
	__u32 ro_wdr_mv_ovsat_cnt;
	__u32 ro_wdr_totally_mv_unsat_cnt;
	__u32 ro_wdr_mv_unsat_cnt;
	__u16 ro_wdr_mv_ovsat_luma;
	__u32 force_still_th1;
	__u32 force_still_mv_unsat_th;
} wdr_req_info_t;

typedef struct ltm_req_info_s {
    uint32_t ltm_dark_floor_u8;
    uint32_t ltm_expblend_thd0;
    uint32_t ltm_expblend_thd1;
    uint32_t ltm_min_factor_u8;
    uint32_t ltm_max_factor_u8;
    uint32_t ltm_bright_floor_u14;
} ltm_req_info_t;

typedef struct lc_req_info_s {
    __u16 min_val_glb;
    __u16 max_val_glb;
}lc_req_info_t;

typedef struct dehaze_req_info_s {
    uint32_t dhz_minvval_lmt[16];
    uint32_t dhz_maxvval_lmt[16];
    uint32_t dhz_lmtrat_lowc;
    uint32_t dhz_lmtrat_higc;
    uint32_t dhz_dlt_rat;
    uint32_t dhz_cc_en;
    uint32_t dhz_hig_dlt_rat;
    uint32_t dhz_low_dlt_rat;
} dehaze_req_info_t;

typedef struct dnlp_req_info_s {
    __u32 ve_dnlp_luma_h;
    __u32 ve_dnlp_luma_l;
    __u32 ro_dnlp_pix_amount;
} dnlp_req_info_t;

typedef struct flkr_req_info_s{
    __u32 flkr_binning_rs;
    __u32 flkr_det_en;
    __u32 flkr_ro_mode;
    __u32 flkr_sta_pos;
    __u32 flkr_tile_hnum;
    __u32 flkr_stat_yst;
    __u32 flkr_stat_yed;
} flkr_req_info_t;

struct c4_isp_module_info {
    top_req_info_t top_req_info;
    wdr_req_info_t wdr_req_info;
    ltm_req_info_t ltm_req_info;
    lc_req_info_t lc_req_info;
    dehaze_req_info_t dehaze_req_info;
    dnlp_req_info_t dnlp_req_info;
    flkr_req_info_t flkr_req_info;
    __u32 debug_en;
};

struct c4_isp_stats_info {
	struct c4_isp_awb_stats awb;
	struct c4_isp_ae_stats ae;
	struct c4_isp_af_stats af;
	struct c4_isp_flkr_stats flkr;
	struct c4_isp_post_stats post;
	struct c4_isp_module_info info;
};

/**
 * enum c4_isp_params_buffer_version -  C4 ISP parameters block versioning
 *
 * @C4_ISP_PARAMS_BUFFER_V0: First version of C4 ISP parameters block
 */
enum c4_isp_params_buffer_version {
	C4_ISP_PARAMS_BUFFER_V0,
};

/**
 * enum c4_isp_params_block_type - Enumeration of C4 ISP parameter blocks
 *
 * Each block configures a specific processing block of the C3 ISP.
 * The block type allows the driver to correctly interpret the parameters block
 * data.
 *
 * @C4_ISP_PARAMS_BLOCK_AWB_GAINS: White balance gains
 * @C4_ISP_PARAMS_BLOCK_AWB_CONFIG: AWB statistic format configuration for all
 *                                  blocks that control how stats are generated
 * @C4_ISP_PARAMS_BLOCK_AE_CONFIG: AE statistic format configuration for all
 *                                 blocks that control how stats are generated
 * @C4_ISP_PARAMS_BLOCK_AF_CONFIG: AF statistic format configuration for all
 *                                 blocks that control how stats are generated
 * @C4_ISP_PARAMS_BLOCK_PST_GAMMA: post gamma parameters
 * @C4_ISP_PARAMS_BLOCK_CCM: Color correction matrix parameters
 * @C4_ISP_PARAMS_BLOCK_CSC: Color space conversion parameters
 * @C4_ISP_PARAMS_BLOCK_BLC: Black level correction parameters
 * @C4_ISP_PARAMS_BLOCK_SENTINEL: First non-valid block index
 */
enum c4_isp_params_block_type {
	C4_ISP_PARAMS_BLOCK_AWB_GAINS,
	C4_ISP_PARAMS_BLOCK_AWB_CONFIG,
	C4_ISP_PARAMS_BLOCK_AE_CONFIG,
	C4_ISP_PARAMS_BLOCK_AF_CONFIG,
	C4_ISP_PARAMS_BLOCK_FLKR_CONFIG,
	C4_ISP_PARAMS_BLOCK_POST_CONFIG,
	C4_ISP_PARAMS_BLOCK_PST_GAMMA,
	C4_ISP_PARAMS_BLOCK_CCM,
	C4_ISP_PARAMS_BLOCK_CSC,
	C4_ISP_PARAMS_BLOCK_BLC,
	C4_ISP_PARAMS_BLOCK_GTM,
	C4_ISP_PARAMS_BLOCK_LENS_MESH,
	C4_ISP_PARAMS_BLOCK_LENS_RAD,
	C4_ISP_PARAMS_BLOCK_LENS_EOTF1,
	C4_ISP_PARAMS_BLOCK_SQRT,
	C4_ISP_PARAMS_BLOCK_LUT3D,
	C4_ISP_PARAMS_BLOCK_DPC,
	C4_ISP_PARAMS_BLOCK_YUVTNR,
	C4_ISP_PARAMS_BLOCK_YUVSNR,
	C4_ISP_PARAMS_BLOCK_YUVCNR,
	C4_ISP_PARAMS_BLOCK_CUBIC,
	C4_ISP_PARAMS_BLOCK_DMSPP,
	C4_ISP_PARAMS_BLOCK_GE,
	C4_ISP_PARAMS_BLOCK_RAWSNR,
	C4_ISP_PARAMS_BLOCK_RAWTNR,
	C4_ISP_PARAMS_BLOCK_DMS,
	C4_ISP_PARAMS_BLOCK_DGAIN,
	C4_ISP_PARAMS_BLOCK_IDGAIN,
	C4_ISP_PARAMS_BLOCK_PK,
	C4_ISP_PARAMS_BLOCK_AMCM,
	C4_ISP_PARAMS_BLOCK_WDR,
	C4_ISP_PARAMS_BLOCK_LTM,
	C4_ISP_PARAMS_BLOCK_LC,
	C4_ISP_PARAMS_BLOCK_DNLP,
	C4_ISP_PARAMS_BLOCK_DHZ,
	C4_ISP_PARAMS_BLOCK_CAC,
	C4_ISP_PARAMS_BLOCK_LBLC,
	C4_ISP_PARAMS_BLOCK_FE_BLC,
	C4_ISP_PARAMS_BLOCK_BAC,
	C4_ISP_PARAMS_BLOCK_BITCMB,
	C4_ISP_PARAMS_BLOCK_DBG,
	C4_ISP_PARAMS_BLOCK_AFC,
	C4_ISP_PARAMS_BLOCK_SENTINEL
};

#define C4_ISP_PARAMS_BLOCK_FL_DISABLE (1U << 0)
#define C4_ISP_PARAMS_BLOCK_FL_ENABLE (1U << 1)

/**
 * struct c4_isp_params_block_header - C4 ISP parameter block header
 *
 * This structure represents the common part of all the ISP configuration
 * blocks. Each parameters block shall embed an instance of this structure type
 * as its first member, followed by the block-specific configuration data. The
 * driver inspects this common header to discern the block type and its size and
 * properly handle the block content by casting it to the correct block-specific
 * type.
 *
 * The @type field is one of the values enumerated by
 * :c:type:`c3_isp_params_block_type` and specifies how the data should be
 * interpreted by the driver. The @size field specifies the size of the
 * parameters block and is used by the driver for validation purposes. The
 * @flags field is a bitmask of per-block flags C3_ISP_PARAMS_FL*.
 *
 * When userspace wants to disable an ISP block the
 * C3_ISP_PARAMS_BLOCK_FL_DISABLED bit should be set in the @flags field. In
 * this case userspace may optionally omit the remainder of the configuration
 * block, which will be ignored by the driver.
 *
 * When a new configuration of an ISP block needs to be applied userspace
 * shall fully populate the ISP block and omit setting the
 * C3_ISP_PARAMS_BLOCK_FL_DISABLED bit in the @flags field.
 *
 * Userspace is responsible for correctly populating the parameters block header
 * fields (@type, @flags and @size) and the block-specific parameters.
 *
 * For example:
 *
 * .. code-block:: c
 *
 *	void populate_pst_gamma(struct c4_isp_params_block_header *block) {
 *		struct c4_isp_params_pst_gamma *gamma =
 *			(struct c4_isp_params_pst_gamma *)block;
 *
 *		gamma->header.type = C4_ISP_PARAMS_BLOCK_PST_GAMMA;
 *		gamma->header.flags = C4_ISP_PARAMS_BLOCK_FL_ENABLE;
 *		gamma->header.size = sizeof(*gamma);
 *
 *		for (unsigned int i = 0; i < 129; i++)
 *			gamma->pst_gamma_lut[i] = i;
 *	}
 *
 * @type: The parameters block type from :c:type:`c4_isp_params_block_type`
 * @flags: A bitmask of block flags
 * @size: Size (in bytes) of the parameters block, including this header
 */
struct c4_isp_params_block_header {
	__u16 type;
	__u16 flags;
	__u32 size;
};

/**
 * struct c4_isp_params_awb_gains - Gains for auto-white balance
 *
 * This struct allows users to configure the gains for white balance.
 * There are four gain settings corresponding to each colour channel in
 * the bayer domain. All of the gains are stored in Q4.8 format.
 *
 * header.type should be set to C4_ISP_PARAMS_BLOCK_AWB_GAINS
 * from :c:type:`c4_isp_params_block_type`
 *
 * @header: The C4 ISP parameters block header
 * @gr_gain: Multiplier for Gr channel (Q4.8 format)
 * @r_gain: Multiplier for R channel (Q4.8 format)
 * @b_gain: Multiplier for B channel (Q4.8 format)
 * @gb_gain: Multiplier for Gb channel (Q4.8 format)
 */
struct c4_isp_params_awb_gains {
	struct c4_isp_params_block_header header;
	__u16 wb_gain[4];
	__u16 wb_limit[4];
	__u8 ae_gain_grbgi[4];
	__u16 ae_bl12_grbgi[4];
	__u16 dpc_rgain;
	__u16 dpc_bgain;

	__u8 wb_rate_rs;
} __attribute__((aligned(8)));

/**
 * enum c4_isp_params_awb_tap_points - Tap points for the AWB statistics
 * @C4_ISP_AWB_STATS_TAP_OFE: immediately after the optical frontend block
 * @C4_ISP_AWB_STATS_TAP_GE: immediately after the green equal block
 * @C4_ISP_AWB_STATS_TAP_BEFORE_WB: immediately before the white balance block
 * @C4_ISP_AWB_STATS_TAP_AFTER_WB: immediately after the white balance block
 */
enum c4_isp_params_awb_tap_points {
	C4_ISP_AWB_STATS_TAP_FE = 0,
	C4_ISP_AWB_STATS_TAP_GE,
	C4_ISP_AWB_STATS_TAP_BEFORE_WB,
	C4_ISP_AWB_STATS_TAP_AFTER_WB,
};

/**
 * struct c4_isp_params_awb_config - Stats settings for auto-white balance
 *
 * This struct allows the configuration of the statistics generated for auto
 * white balance.
 *
 * header.type should be set to C4_ISP_PARAMS_BLOCK_AWB_CONFIG
 * from :c:type:`c4_isp_params_block_type`
 *
 * @header: the C4 ISP parameters block header
 * @tap_point: the tap point from enum c4_isp_params_awb_tap_point
 * @satur_vald: AWB statistic over saturation control
 *		value: 0: disable, 1: enable
 * @blk_hnum: active number of horizontal zones [0..16]
 * @blk_vnum: active number of vertical zones [0..24]
 * @rg_min: minimum R/G ratio (Q4.8 format)
 * @rg_max: maximum R/G ratio (Q4.8 format)
 * @bg_min: minimum B/G ratio (Q4.8 format)
 * @bg_max: maximum B/G ratio (Q4.8 format)
 * @rg_low: R/G ratio trim low (Q4.8 format)
 * @rg_high: R/G ratio trim hight (Q4.8 format)
 * @bg_low: B/G ratio trim low (Q4.8 format)
 * @bg_high: B/G ratio trim high (Q4.8 format)
 * @zone_weight: array of weights for AWB statistics zones [0..15]
 * @horiz_coord: the horizontal coordinate of points on the diagonal [0..2888]
 * @vert_coord: the vertical coordinate of points on the diagonal [0..2240]
 */
struct c4_isp_params_awb_config {
	struct c4_isp_params_block_header header;
	__u8 tap_point;
	__u8 domain_sel;
	__u8 blk_hnum;
	__u8 blk_vnum;
	__u16 blk_hstep;
	__u16 blk_vstep;

	__u8 roi_enable;
	__u16 win_hstart;
	__u16 win_hsize;
	__u16 win_vstart;
	__u16 win_vsize;

	__u8 satur_vald;
	__u16 rg_min;
	__u16 rg_max;
	__u16 bg_min;
	__u16 bg_max;
	__u16 rg_low;
	__u16 rg_high;
	__u16 bg_low;
	__u16 bg_high;

	__u16 stat_blc[4];
	__u16 stat_gain[4];
	__u16 stat_satur_low;
	__u16 stat_satur_high;
	__u8 grn_use_avg;

	__u8 stat_flt_mode;
	__u8 stat_local_mode;

	__u8 blk_weight[C4_ISP_AWB_MAX_ZONES];
	__u8 input_2ln;
} __attribute__((aligned(8)));

/**
 * enum c4_isp_params_ae_tap_points - Tap points for the AE statistics
 * @C4_ISP_AE_STATS_TAP_GE: immediately after the green equal block
 * @C4_ISP_AE_STATS_TAP_MLS: immediately after the mesh lens shading block
 */
enum c4_isp_params_ae_tap_points {
	C4_ISP_AE_STATS_TAP_GE = 0,
	C4_ISP_AE_STATS_TAP_MLS,
};

/**
 * struct c4_isp_params_ae_config - Stats settings for auto-exposure
 *
 * This struct allows the configuration of the statistics generated for
 * auto exposure.
 *
 * header.type should be set to C4_ISP_PARAMS_BLOCK_AE_CONFIG
 * from :c:type:`c4_isp_params_block_type`
 *
 * @header: the C4 ISP parameters block header
 * @horiz_zones_num: active number of horizontal zones [0..17]
 * @vert_zones_num: active number of vertical zones [0..15]
 * @tap_point: the tap point from enum c3_isp_params_ae_tap_point
 * @zone_weight: array of weights for AE statistics zones [0..15]
 * @horiz_coord: the horizontal coordinate of points on the diagonal [0..2888]
 * @vert_coord: the vertical coordinate of points on the diagonal [0..2240]
 * @reserved: applications must zero this array
 */
struct c4_isp_params_ae_config {
	struct c4_isp_params_block_header header;
	__u8 tap_point;
	__u8 domain_sel;
	__u8 blk_hnum;
	__u8 blk_vnum;
	__u16 blk_hstep;
	__u16 blk_vstep;

	__u8 blk_weight[C4_ISP_AE_MAX_ZONES];

	__u8 stat_hist_mode;
	__u16 stat_thrd[4];
	__u8 luma_mode;
	__u8 input_2ln;
	__u8 expos_stt;
	__u8 stat_sqrt_mode;
} __attribute__((aligned(8)));

/**
 * enum c4_isp_params_af_tap_points - Tap points for the AF statistics
 * @C4_ISP_AF_STATS_TAP_SNR: immediately after the spatial noise reduce block
 * @C4_ISP_AF_STATS_TAP_DMS: immediately after the demosaic block
 */
enum c4_isp_params_af_tap_points {
	C4_ISP_AF_STATS_TAP_SNR = 0,
	C4_ISP_AF_STATS_TAP_DMS,
};

/**
 * struct c4_isp_params_af_config - Stats settings for auto-focus
 *
 * This struct allows the configuration of the statistics generated for
 * auto focus.
 *
 * header.type should be set to C4_ISP_PARAMS_BLOCK_AF_CONFIG
 * from :c:type:`c4_isp_params_block_type`
 *
 * @header: the C4 ISP parameters block header
 * @tap_point: the tap point from enum c3_isp_params_af_tap_point
 * @horiz_zones_num: active number of horizontal zones [0..17]
 * @vert_zones_num: active number of vertical zones [0..15]
 * @reserved: applications must zero this array
 * @horiz_coord: the horizontal coordinate of points on the diagonal [0..2888]
 * @vert_coord: the vertical coordinate of points on the diagonal [0..2240]
 */
struct c4_isp_params_af_config {
	struct c4_isp_params_block_header header;
	__u8 tap_point;
	__u8 domain_sel;
	__u8 blk_hnum;
	__u8 blk_vnum;
	__u16 blk_hstep;
	__u16 blk_vstep;
	__u8 ast_blk_vidx;
	__u8 ast_blk_sft;
	__u8 ast_blk_gain;
	__u8 reserved[5];

	__u8 stat_sel;
} __attribute__((aligned(8)));

enum c4_isp_params_flkr_tap_points {
	C4_ISP_FLKR_STATS_TAP_FEO = 0,
	C4_ISP_FLKR_STATS_TAP_NR,
	C4_ISP_FLKR_STATS_TAP_POST,
};

struct c4_isp_params_flkr_config {
	struct c4_isp_params_block_header header;
	__u8 tap_point;
	__u8 domain_sel;
	__u8 binning_rs;
	__u16 stat_xst;
	__u16 stat_xed;
	__u16 stat_yst;
	__u16 stat_yed;

	__u16 wdr_ratio;
	__u16 stat_div_coef;
} __attribute__((aligned(8)));

struct c4_isp_params_post_config {
	struct c4_isp_params_block_header header;
	__u16 blk_hidx[13];
	__u16 blk_vidx[9];
	__u16 lcsta_hidx[13];
	__u16 lcsta_vidx[9];
	__u8 blk_hnum;
	__u8 blk_vnum;
	__u8 lcsta_hnum;
	__u8 lcsta_vnum;

	__u16 pst_glbwin_hstart;
	__u16 pst_glbwin_hend;
	__u16 pst_glbwin_vstart;
	__u16 pst_glbwin_vend;

	__u16 dnlp_glbwin_hstart;
	__u16 dnlp_glbwin_hend;
	__u16 dnlp_glbwin_vstart;
	__u16 dnlp_glbwin_vend;
	__u8 pdpc_en;
	__u8 bsc_en;
} __attribute__((aligned(8)));

/**
 * struct c4_isp_params_pst_gamma - Post gamma configuration
 *
 * This struct allows the configuration of the look up table for
 * post gamma. The gamma curve consists of 129 points, so need to
 * set lut[129].
 *
 * header.type should be set to C4_ISP_PARAMS_BLOCK_PST_GAMMA
 * from :c:type:`c4_isp_params_block_type`
 *
 * @header: the C4 ISP parameters block header
 * @lut: lookup table for P-Stitch gamma [0..1023]
 * @reserved: applications must zero this array
 */
struct c4_isp_params_pst_gamma {
	struct c4_isp_params_block_header header;
	__u16 lut[129];
	__u16 reserved[3];
} __attribute__((aligned(8)));

/**
 * struct c4_isp_params_ccm - ISP CCM configuration
 *
 * This struct allows the configuration of the matrix for
 * color correction. The matrix consists of 3 x 3 points,
 * so need to set matrix[3][3].
 *
 * header.type should be set to C4_ISP_PARAMS_BLOCK_CCM
 * from :c:type:`c4_isp_params_block_type`
 *
 * @header: the C4 ISP parameters block header
 * @matrix: a 3 x 3 matrix used for color correction,
 *          the value of matrix[x][y] is orig_value x 256. [-4096..4095]
 * @reserved: applications must zero this array
 */
struct c4_isp_params_ccm {
	struct c4_isp_params_block_header header;
	__u8 cr_by_luma[17];
	__u8 cr_by_sat[17];
	__u8 neg_prot_str;
	__u16 matrix[3][3];

	__u8 cr_en;
} __attribute__((aligned(8)));

/**
 * struct c4_isp_params_csc - ISP Color Space Conversion configuration
 *
 * This struct allows the configuration of the matrix for color space
 * conversion. The matrix consists of 3 x 3 points, so need to set matrix[3][3].
 *
 * header.type should be set to C3_ISP_PARAMS_BLOCK_CSC
 * from :c:type:`c4_isp_params_block_type`
 *
 * @header: the C4 ISP parameters block header
 * @matrix: a 3x3 matrix used for the color space conversion,
 *          the value of matrix[x][y] is orig_value x 256. [-4096..4095]
 * @reserved: applications must zero this array
 */
struct c4_isp_params_csc {
	struct c4_isp_params_block_header header;
	__u16 matrix[3][3];
	__u16 lc_yuv2rgb_mat3x3[9];
	__u16 offset_inp[3];
	__u16 offset_oup[3];
	__u8 mtrx_rs;
	__u16 lc_yuv2rgb_ofset[2];
	__u16 lc_yuv2rgb_clip[2];
	__u8 lc_yuv2rgb_rs;
	__u16 lcsta_csc_preofst[2];
	__u16 lcsta_csc_pstofst[2];
} __attribute__((aligned(8)));

/**
 * struct c4_isp_params_blc - ISP Black Level Correction configuration
 *
 * This struct allows the configuration of the block level offset for each
 * color channel.
 *
 * header.type should be set to C4_ISP_PARAMS_BLOCK_BLC
 * from :c:type:`c4_isp_params_block_type`
 *
 * @header: the C4 ISP parameters block header
 * @gr_ofst: Gr blc offset (Q4.12 format)
 * @r_ofst: R blc offset (Q4.12 format)
 * @b_ofst: B blc offset (Q4.12 format)
 * @gb_ofst: Gb blc offset(Q4.12 format)
 */
struct c4_isp_params_blc {
	struct c4_isp_params_block_header header;
	__u16 blc_ofst[4];
	__u16 idg_ofst;
	__u16 dg_ofst;
	__u16 ge_blc_ofst[2];
	__u16 dpc_bl;
	__u16 dpc_fc_sat_th;
	__u32 sqrt_pre_ofst;
	__u16 sqrt_pst_ofst;
	__u16 eotf_pre_ofst;
	__u32 eotf_pst_ofst;
	__u16 rawtnr_black_level;
	__u16 rawsnr_black_level;
	__u16 rawtsnr_mn_pre_ofst;
	__u8 blc_ext_en;
} __attribute__((aligned(8)));

struct c4_isp_params_gtm {
	struct c4_isp_params_block_header header;
	__u16 lut[129];

	__u8 lut_mode;
} __attribute__((aligned(8)));

struct c4_isp_params_lens_mesh {
	struct c4_isp_params_block_header header;
	__u8 mesh_alpmode;
	__u8 mesh_hlut_mode;
	__u8 mesh_vlut_mode;
	__u8 mesh_lutnorm_grbg[3];
	__u8 mesh_xnum;
	__u8 mesh_ynum;
	__u8 mesh_xlimit;
	__u8 mesh_ylimit;
	__u32 mesh_xscale;
	__u32 mesh_yscale;

	__u8 mesh_alp[4];
	__u16 mesh_strength;

	__u8 mesh_prtmode;

	__u8 light_update;
	__u8 light0_lut[768];
	__u8 light1_lut[768];
	__u8 light2_lut[768];
	__u8 light3_lut[768];
} __attribute__((aligned(8)));

struct c4_isp_params_lens_rad {
	struct c4_isp_params_block_header header;
	__u16 rad_strength;

	__u16 rad_xscale;
	__u16 rad_yscale;
	__u16 rad_center_x;
	__u16 rad_center_y;
	__u16 rad_mult_gain[3];
	__u8 rad_centofst_x[3];
	__u8 rad_centofst_y[3];

	__u8 lut_update;
	__u16 lut[49][3];
} __attribute__((aligned(8)));

struct c4_isp_params_lens_eotf1 {
	struct c4_isp_params_block_header header;
	__u32 lut[129];

	__u8 eotf1_mode;
	__u8 eotf1_num[8];
	__u8 eotf1_stp[8];
} __attribute__((aligned(8)));

struct c4_isp_params_sqrt {
	struct c4_isp_params_block_header header;
	__u32 lut0[33];
	__u32 lut1[129];

	__u8 sqrt1_mode;
	__u8 sqrt1_num[8];
	__u8 sqrt1_stp[8];
} __attribute__((aligned(8)));

struct c4_isp_params_lut3d {
	struct c4_isp_params_block_header header;
	__u16 lut[729][3];

	__u8 mode[3];
} __attribute__((aligned(8)));

struct c4_isp_params_dpc {
	struct c4_isp_params_block_header header;
	__u8 dyn_en;
	__u8 stc_en;
	__u8 fc_en;
	__u8 sec_en;
	__u8 bad_cor_en;
	__u8 deshrp_cor_en;
	__u8 nr_en;
	__u8 ehn_en;
	__u8 pr_en;
	__u8 pr_phssel[16];
	__u8 pr_blksel[16];
	__u16 btbad_dif_ofs;
	__u8 btbad_dif_th;
	__u8 btbad_rat_th;
	__u8 btbad_dtl_ofs;
	__u8 btbad_dtl_th;
	__u16 dkbad_dif_ofs;
	__u8 dkbad_dif_th;
	__u8 dkbad_rat_th;
	__u8 dkbad_dtl_ofs;
	__u8 dkbad_dtl_th;
	__u16 deshrpbt_dif_ofs;
	__u8 deshrpbt_dif_th;
	__u8 deshrpbt_rat_th;
	__u16 deshrpdk_dif_ofs;
	__u8 deshrpdk_dif_th;
	__u8 deshrpdk_rat_th;
	__u8 deshrp_str;
	__u8 bad_str;
	__u16 fc_rng;
	__u16 fc_rng_slp;
	__u8 nr_flat_str[2];
	__u8 nr_dtal_str[2];

	__u32 lut[256];
} __attribute__((aligned(8)));

struct c4_isp_params_yuvtnr {
	struct c4_isp_params_block_header header;
	__u8 pre_y_frm_option;
	__u8 pre_c_frm_option;
	__u8 ssad_fine_diff_th[4];
	__u8 max_grad_diff_th[4];
	__u8 mn_var_diff_th[4];
	__u8 pro_var_diff_th[4];
	__u8 mn_fine_diff_th[4];
	__u8 alpha_ds_pro_mode;
	__u8 sd_use_y_only;
	__u8 mn_sad_thn_coarse[9];
	__u8 mn_sad2alpha_coarse[9];
	__u8 mn_sad2alpha_fine[9];
	__u8 iir_alpha_luma_gain[9];
	__u8 pro_sad_thn_coarse[9];
	__u8 pro_sad2alpha_coarse[9];
	__u8 iir_alpha_var_diff_th0;
	__u8 iir_alpha_var_diff_gain[4];
	__u8 pro_sad_cor_gain;
	__u8 pro_sad_cor_ofst;
	__u8 mn_fine_sad_cor_gain;
	__u8 mn_fine_sad_cor_ofst;
	__u8 mn_coarse_sad_cor_gain;
	__u8 mn_coarse_sad_cor_ofst;
	__u8 pro_sad_cor_lut[17];
	__u8 mn_coarse_sad_cor_lut[17];
	__u8 mn_fine_sad_cor_lut[17];
	__u8 mn_fine_cor_var_gain[4];
	__u8 y_diff_gain;
	__u8 c_diff_gain;
	__u8 mn_max_grad_diff_gain[4];
	__u8 mn_var_diff_gain[4];
	__u8 pro_var_diff_gain[4];
	__u8 mn_fine_diff_gain[4];
	__u8 meta_clip_alpha_lut[12];
	__u8 alpha2meta_add_th;
	__u8 alpha2meta_rst_th;
	__u8 fine_str;
	__u8 mn_coarse_sad_multi_factor;
	__u8 mn_fine_sad_multi_factor;
	__u8 mn_fine_diff_multi_factor;
	__u8 mn_ssad_bld_ratio[4];
	__u8 pro_sad_multi_factor;
	__u8 pro_ssad_bld_ratio[4];
	__u8 iir_alpha_ds_pro_bld_ratio;
	__u8 var_multi_factor[2];
	__u8 edge_sad_multi_factor;
	__u8 coarse_alpha_max;
	__u8 fine_alpha_max;

	__u16 rad_center_x;
	__u16 rad_center_y;

	__u8 mn_mix_en;
	__u8 mn_coarse_alpha_filt_en;
	__u8 mn_fine_alpha_filt_en;
	__u8 mn_alpha_filt_win_mode;
} __attribute__((aligned(8)));

struct c4_isp_params_yuvsnr {
	struct c4_isp_params_block_header header;
	__u8 luma_wt_lut[16];
	__u8 cor_nlel_gain;
	__u16 cor_nlel_ofst;
	__u8 cor_var_th[3];
	__u8 cor_var_gain[3];
	__u8 cor_luma_th[3];
	__u8 cor_luma_gain[3];
	__u8 nlel_lut16[16];
	__u8 wt_luma_th[3];
	__u8 wt_luma_gain[3];
	__u8 wt_var_th[3];
	__u8 wt_var_gain[3];
	__u8 pdpc_ic_mimx_mode;
	__u8 pdpc_lpf_alp;
	__u8 pdpc_thrd[5];
	__u8 wt_meta2alpha[16];
	__u8 cor_meta2alpha[16];
	__u16 c_sad_sigma_th[4];
	__u8 c_sad_sigma_value[3];
	__u16 c_color_wt_mdif_th[2];
	__u8 c_sad_th_meta2alpha[16];
	__u8 c_dis_wt_lut[16];

	__u16 rad_center_x;
	__u16 rad_center_y;
} __attribute__((aligned(8)));

struct c4_isp_params_yuvcnr {
	struct c4_isp_params_block_header header;
} __attribute__((aligned(8)));

struct c4_isp_params_cubic {
	struct c4_isp_params_block_header header;
} __attribute__((aligned(8)));

struct c4_isp_params_dmspp {
	struct c4_isp_params_block_header header;
	__u8 pfr_cor_r_str;
	__u8 pfr_cor_g_str;
	__u8 pfr_cor_b_str;
	__u8 pfr_max_luma_thd;
	__u8 pfr_max_luma_slope;
	__u8 pfr_ldif_grad_thd;
	__u16 pfr_ldif_grad_slope;
	__u8 pfr_max_max_grad_thd;
	__u16 pfr_max_max_grad_slope;
	__u8 pfr_mean_min_grad_thd;
	__u16 pfr_mean_min_grad_slope;
	__u8 pfr_hue_thd_h;
	__u8 pfr_hue_thd_l;
	__u8 pfr_hue_slope_h;
	__u8 pfr_hue_slope_l;
	__u8 pfr_lite_gain;
	__u8 pfr_ref1_str;
	__u8 pfr_ref2_str;
	__u8 pfr_cor_max_exwt;
	__u8 pfr_org_ext_proc_mode;
	__u8 pfr_dbg_mode;
	__u8 pfr_sat_wt_lut[8];
	__u8 pfr_en;
	__u8 afc_en;
	__u8 pfr_cor_g_en;
	__u8 pfr_non_maxl_thd;
	__u8 pfr_non_maxl_slope;
	__u8 pfr_curl_thd;
	__u8 pfr_curl_slope;
} __attribute__((aligned(8)));

struct c4_isp_params_afc_ctl {
	struct c4_isp_params_block_header header;
	__u8 grad_th;
	__u8 grad_cnt;
	__u16 grad_cnt_slope;
	__u16 cerr_th;
	__u16 cerr_slope;
	__u16 color_th;
	__u16 color_slope;
	__u8 color_cnt;
	__u8 luma_th;
	__u8 luma_gain;
	__u16 luma_slope;
} __attribute__((aligned(8)));

struct c4_isp_params_ge {
	struct c4_isp_params_block_header header;
	__u16 lpf_edge_th0[2];
	__u16 hv_thrd[2];
	__u8 hv_wtlut_0[4];
	__u8 hv_wtlut_1[4];
} __attribute__((aligned(8)));

struct c4_isp_params_rawsnr {
	struct c4_isp_params_block_header header;
	__u8 bld_g_ratio;
	__u8 bld_r_ratio;
	__u8 bld_b_ratio;
	__u8 blk_sad_factor[5];
	__u8 bld_wdr_mask_gain[5];
	__u8 ge_flat_rate;
	__u8 sigma_shading_gain_en;
	__u8 wdr_mask_bld_ratio_en;
	__u8 bld_luma_thn[9];
	__u8 sigma_shading_gain[9];
	__u8 bld_luma_gain[9];
	__u8 sigma_center_weight;
	__u8 sigma_th1_weight;
	__u8 sigma_th1;
	__u8 sigma_th2_weight;
	__u8 sigma_th2;
	__u8 sigma_th3_weight;
	__u8 sigma_th3;
	__u8 sigma_th4_weight;
	__u8 sigma_th4;
} __attribute__((aligned(8)));

struct c4_isp_params_rawtnr {
	struct c4_isp_params_block_header header;
	__u8 ssad_var_diff_th[4];
	__u8 rawtsnr_mn_mode;
	__u8 yuvtnr_mn_mode;
	__u8 yuvtnr_mn_mix_en;
	__u8 yuvtnr_mn_sd_option;
	__u8 mn_awb_r_gain;
	__u8 mn_awb_b_gain;
	__u16 np_lut33[33];
	__u8 sad_cor_gain;
	__u8 iir_alpha_coarse_max;
	__u8 iir_alpha_fine_max;
	__u8 snr_g_min_alpha;
	__u8 snr_rb_min_alpha;
	__u16 fine_mn_gain;
	__u8 sad_pp_multi_factor[5];
	__u16 sad_scale_ratio[5];
	__u8 var_multi_factor[5];
	__u8 ssad_bld_ratio[4];
	__u8 sad2alpha_lut_coarse[9];
	__u8 sad2alpha_lut_fine[9];
	__u8 snr_alpha_lut[9];
	__u16 rawtsnr_mn_lut[17];

	__u16 shading_center_x;
	__u16 shading_center_y;
} __attribute__((aligned(8)));

struct c4_isp_params_dms {
	struct c4_isp_params_block_header header;
	__u8 boost_shift;
	__u8 pipe2b_org_en;
	__u8 drt_ambg_hfrq_thd;
	__u8 afc_color_alpha;
	__u8 boost_via_grad[11];
	__u8 boost_via_grad_ratio[10];
	__u8 afc_cdif_rng_lut[3];

	__u8 rb_cerr_gain;
	__u8 ambg_ref_en_0;
	__u8 ambg_ref_en_4;
	__u8 ambg_grad_th;

	__u8 ambg_grad_lut[7][7];
} __attribute__((aligned(8)));

struct c4_isp_params_dgain {
	struct c4_isp_params_block_header header;
	__u16 dg_gain[4];
} __attribute__((aligned(8)));

struct c4_isp_params_idgain {
	struct c4_isp_params_block_header header;
	__u16 idg_gain[4];
} __attribute__((aligned(8)));

struct c4_isp_params_pk {
	struct c4_isp_params_block_header header;
	__u8 fine_final_gain;
	__u8 nry_strength;
	__u8 fine_motion_adp_gain_lut[8];
	__u8 fine_motion_adp_nry_str_lut[8];
	__u16 os_up_via_alp[9];
	__u16 os_dw_via_alp[9];
	__u8 cir_gain_table[12];
	__u8 drt_gain_table[12];
	__u8 cir_gain_table_w[12];
	__u8 drt_gain_table_w[12];
	__u16 color0_uv_st[2];
	__u16 color1_uv_st[2];
	__u16 pfr_u_st;
	__u16 pfr_v_st;
	__u8 gain_vsluma_lut[9];
	__u16 pre_bpc_margin;
	__u8 nr_cst_y0;
	__u8 nr_cst_y1;
	__u8 drtlpf_alpha[12];
	__u8 bphp_drtblend_via_gradlut[9];
	__u8 bphp_cirblend_via_gradlut[9];
	__u8 osv_winsize;
	__u8 osh_winsize;
	__u8 sml_agl_ctl;
	__u8 dps_drtlpf_en;
	__u8 debug_mode;
	__u8 motion_adp_en;
	__u8 motion_nr_adp_en;
	__u8 color_enable[2];
	__u8 bpf_vdtap05[3];
	__u8 hpf_vdtap05[3];
	__u8 bpf_hztap09[5];
	__u8 hpf_hztap09[5];
	__u8 osht_vsluma_lut[9];
	__u8 osht_w_vsluma_lut[9];
	__u8 drt_gain_table_via_fir[10];
	__u8 drt_gain_table_w_via_fir[10];
	__u8 circ_bpf_2d5x7[3][4];
	__u8 circ_hpf_2d5x7[3][4];

	__u8 hlc_en;
	__u16 hlc_luma_thd;
	__u16 hlc_luma_trgt;

	__u8 color0_lut2d[36];
	__u8 alp2_lut2d[36];
	__u8 drtbld_beta_en;
	__u8 drtbld_beta[4];
	__u8 alp2_averstderr_lut2d[30];
	__u8 flt_src_mux;
	__u8 pre_art_rmv_en;
	__u8 pre_bpc_en;
	__u8 pre_bpc_strength;
	__u8 drtlpf_theta_min_idx_replace;
} __attribute__((aligned(8)));

struct c4_isp_params_amcm {
	struct c4_isp_params_block_header header;
	__u16 cm2_global_sat;
	__u16 cm2_luma_contrast;
	__u16 cm2_global_hue;
	__u16 cm2_luma_brightness;
	__u8 cm2_adj_satglbgain_via_y[17];
	__u8 cm2_adj_satglbgain_via_sat[33];
	__u8 cm2_adj_sat_via_h[32];
	__u8 cm2_adj_hue_via_h[32];
} __attribute__((aligned(8)));

struct c4_isp_params_wdr {
	struct c4_isp_params_block_header header;
	__u16 lexpratio_int64;
	__u8  expcomb_slope_weight;
	__u16 expcomb_blend_slope;
	__u16 expcomb_blend_thd0;
	__u16 expcomb_blend_thd1;
	__u16 expcomb_maxratio;
	__u16 comb_expratio_int64;
	__u16 comb_exprratio_int1024;
	__u16 comb_maxratio;

	__u8  motiondect_en;
	__u8  force_exp_en;
	__u8  force_exp_mode;
	__u8  mdeci_still_thd;
	__u8  force_mask_en;
	__u8  force_long_mode;
	__u8  short_add_ratio;
	__u8  expcomb_maxavg_mode;
	__u8  expcomb_maxavg_ratio;
	__u8  force_short_en;
	__u8  force_short_bld_en;

	__u16 mdetc_sat_thd[4];
	__u16 mdetc_sat_rgb_thd[3];
	__u16 comb_lsbarrier[4];
	__u8  mdetc_lo_th;
	__u8  mdetc_hi_th;
	__u8  mdetc_noise_idx_mode;
	__u16 mdetc_noise_profile[17];
	__u16 mdetc_noise_ofs;
	__u16 mdetc_noise_gain;
	__u16 mdetc_noise_rundth_gain;
	__u16 mdetc_noise_th_gain;
	__u16 mdetc_noise_th[17];
	__u16 mdetc_sat_sthd[4];
	__u16 mdetc_sat_rgb_sthd[3];
	__u16 mdeci_os_luma_thr;

	__u32 force_still_th0;
	__u32 force_still_th1;
	__u32 force_still_mv_unsat_th;
	__u16 force_short_osmv_th0;
	__u16 force_short_osmv_th1;
	__u32 force_short_mv_unsat_th;
	__u16 force_short_luma_th;

	__u8  sensor_bitdepth;
	__u8  expcomb_desat_by_luma_lut[17];
	__u8  expcomb_desat_by_sat_lut[17];
	__u8  expcomb_dpf_by_sat_lut[17];
	__u8  mdeci_coring_lut[17];

	__u8  expcomb_desat_str[2];
	__u8  expcomb_flt_str;
	__u8  expcomb_short_desat_en;
	__u8  expcomb_short_flt_str;
	__u8  expcomb_blend_ythd0;
	__u8  expcomb_blend_ythd1;
	__u8  expcomb_blend_xthd;
	__u8  expcomb_blend_kappa;

	__u8  expcomb_desat_r_str[2];
	__u8  expcomb_desat_g_str[2];
	__u8  expcomb_desat_b_str[2];

	__u8  expcomb_dpf_en;
	__u16 expcomb_dpf_luma_th;
	__u16 expcomb_dpf_grad_th;
	__u16 expcomb_dpf_grad_diff_th;
	__u8  expcomb_dpf_r_str[2];
	__u8  expcomb_dpf_g_str[2];
	__u8  expcomb_dpf_b_str[2];

	__u8  expcomb_long_enhn_en;
	__u8  expcomb_short_denos_en;
	__u8  expcomb_long_enhn_lut[9];
	__u16 expcomb_long_enhn_limit;

	__u16 mdeci_awb_r_limit;
	__u16 mdeci_awb_b_limit;
	__u16 awb_gain_256[4];
	__u16 expcomb_desat_awb_c[2];
	__u16 blc_ofst[4];
	__u16 mdeci_short_expo_chk_th;
	__u16 force_stat_hstep;
	__u16 force_stat_vstep;
	__u16 force_stat_hscale;
	__u16 force_stat_vscale;
	__u8  force_stat_hnum;
	__u8  force_stat_vnum;
	__u16 force_stat_rtscale;
	__u16 force_stat_btscale;
	__u16 force_stat_brscale;
	__u8  og_en;
} __attribute__((aligned(8)));

struct c4_isp_params_ltm {
	struct c4_isp_params_block_header header;
	__u16 hi_gm_u10;
	__u16 lo_gm_u10;
	__u32 aph;
	__u16 beta;
	__u8 cc_en;
	__u8 vs_gtm_alpha;
	__u8 b2luma_alpha;
	__u8 drop_en;
	__u16 sat_th;
	__u16 max_diff_th;
	__u16 maxmin_diff_th;
	__u8 drop_ratio;
	__u16 sat_ratio;
	__u16 max_min_diff_ratio;
	__u8 drop_bld_ratio;
	__u16 gain_min;
	__u8 gain_max;
	__u8 line_buf_mode;
} __attribute__((aligned(8)));

struct c4_isp_params_lc {
	struct c4_isp_params_block_header header;
	__u8 ram_lcmap_update;
	__u16 ram_lcmap_nodes[96][6];

	__u8 cc_en;
	__u8 blkblend_mode;

	__u8 satur_lut_update;
	__u16 satur_lut[63];
} __attribute__((aligned(8)));

struct c4_isp_params_dnlp {
	struct c4_isp_params_block_header header;
	__u16 ygrid[64];
} __attribute__((aligned(8)));

struct c4_isp_params_dhz {
	struct c4_isp_params_block_header header;
	__u16 atmos_light;
	__u16 atmos_light_inver;
	__u16 sky_prot_stre;
	__u16 sky_prot_offset;
	__u8 satura_ratio_sky;
	__u16 min_cut_ratio;
	__u16 max_cut_ratio;
	__u8 sky_prot_en;
	__u16 sky_prot_lut[64];
} __attribute__((aligned(8)));

struct c4_isp_params_cac {
	struct c4_isp_params_block_header header;
	__u16 rad_rg_center_x;
	__u16 rad_rg_center_y;
	__u16 rad_bg_center_x;
	__u16 rad_bg_center_y;
	__u8 norm_inv_depth;
	__u16 norm_inv;
	__u8 st_dist;
	__u8 coef_norm;
	__u16 coef_r[3];
	__u16 coef_b[3];
} __attribute__((aligned(8)));

struct c4_isp_params_lblc {
	struct c4_isp_params_block_header header;
	__u8 lblc_en;
	__u8 mode;
	__u16 glb[4];
	__u16 xscale;
	__u16 yscale;

	__u16 xshift;
	__u16 yshift;
	__u8 xnum;
	__u8 ynum;

	__u8 lut[2][1156];
} __attribute__((aligned(8)));

struct c4_isp_params_fe_blc {
	struct c4_isp_params_block_header header;
	__u32 bl_ofst[4];
} __attribute__((aligned(8)));

struct c4_isp_params_bac {
	struct c4_isp_params_block_header header;
	__u8 bac_en;
	__u8 hcoef[4];
	__u8 vcoef[4];
} __attribute__((aligned(8)));

struct c4_isp_params_bitcmb {
	struct c4_isp_params_block_header header;
	__u8 mode;
	__u8 sbit;
	__u8 ibit;
	__u8 obit;
} __attribute__((aligned(8)));

struct c4_isp_params_dbg {
	struct c4_isp_params_block_header header;
	__u8 dma_mode;
} __attribute__((aligned(8)));

/**
 * define C4_ISP_PARAMS_MAX_SIZE - Maximum size of all C4 ISP Parameters
 *
 * Though the parameters for the C4 ISP are passed as optional blocks, the
 * driver still needs to know the absolute maximum size so that it can allocate
 * a buffer sized appropriately to accommodate userspace attempting to set all
 * possible parameters in a single frame.
 */
#define C4_ISP_PARAMS_MAX_SIZE                                \
	(sizeof(struct c4_isp_params_awb_gains) +             \
	 sizeof(struct c4_isp_params_awb_config) +            \
	 sizeof(struct c4_isp_params_ae_config) +             \
	 sizeof(struct c4_isp_params_af_config) +             \
	 sizeof(struct c4_isp_params_flkr_config) +           \
	 sizeof(struct c4_isp_params_post_config) +           \
	 sizeof(struct c4_isp_params_pst_gamma) +             \
	 sizeof(struct c4_isp_params_ccm) +                   \
	 sizeof(struct c4_isp_params_csc) +                   \
	 sizeof(struct c4_isp_params_blc) +                   \
	 sizeof(struct c4_isp_params_gtm) +                   \
	 sizeof(struct c4_isp_params_lens_mesh) +             \
	 sizeof(struct c4_isp_params_lens_rad) +              \
	 sizeof(struct c4_isp_params_lens_eotf1) +            \
	 sizeof(struct c4_isp_params_sqrt) +                  \
	 sizeof(struct c4_isp_params_lut3d) +                 \
	 sizeof(struct c4_isp_params_dpc) +                   \
	 sizeof(struct c4_isp_params_yuvtnr) +                \
	 sizeof(struct c4_isp_params_yuvsnr) +                \
	 sizeof(struct c4_isp_params_yuvcnr) +                \
	 sizeof(struct c4_isp_params_cubic) +                 \
	 sizeof(struct c4_isp_params_dmspp) +                 \
	 sizeof(struct c4_isp_params_ge) +                    \
	 sizeof(struct c4_isp_params_rawsnr) +                \
	 sizeof(struct c4_isp_params_rawtnr) +                \
	 sizeof(struct c4_isp_params_dms) +                   \
	 sizeof(struct c4_isp_params_dgain) +                 \
	 sizeof(struct c4_isp_params_idgain) +                \
	 sizeof(struct c4_isp_params_pk) +                    \
	 sizeof(struct c4_isp_params_amcm) +                  \
	 sizeof(struct c4_isp_params_wdr) +                   \
	 sizeof(struct c4_isp_params_ltm) +                   \
	 sizeof(struct c4_isp_params_lc) +                    \
	 sizeof(struct c4_isp_params_dnlp) +                  \
	 sizeof(struct c4_isp_params_dhz) +                   \
	 sizeof(struct c4_isp_params_cac) +                   \
	 sizeof(struct c4_isp_params_lblc) +                  \
	 sizeof(struct c4_isp_params_fe_blc) +                \
	 sizeof(struct c4_isp_params_bac) +                   \
	 sizeof(struct c4_isp_params_bitcmb) +                \
	 sizeof(struct c4_isp_params_afc_ctl) +               \
	 sizeof(struct c4_isp_params_dbg))

/**
 * struct c4_isp_params_cfg - C4 ISP configuration parameters
 *
 * This struct contains the configuration parameters of the C4 ISP
 * algorithms, serialized by userspace into an opaque data buffer. Each
 * configuration parameter block is represented by a block-specific structure
 * which contains a :c:type:`c3_isp_param_block_header` entry as first
 * member. Userspace populates the @data buffer with configuration parameters
 * for the blocks that it intends to configure. As a consequence, the data
 * buffer effective size changes according to the number of ISP blocks that
 * userspace intends to configure.
 *
 * The parameters buffer is versioned by the @version field to allow modifying
 * and extending its definition. Userspace should populate the @version field to
 * inform the driver about the version it intends to use. The driver will parse
 * and handle the @data buffer according to the data layout specific to the
 * indicated revision and return an error if the desired revision is not
 * supported.
 *
 * For each ISP block that userspace wants to configure, a block-specific
 * structure is appended to the @data buffer, one after the other without gaps
 * in between nor overlaps. Userspace shall populate the @total_size field with
 * the effective size, in bytes, of the @data buffer.
 *
 * The expected memory layout of the parameters buffer is::
 *
 *	+-------------------- struct c4_isp_params_cfg ---- ------------------+
 *	| version = C4_ISP_PARAM_BUFFER_V0;                                   |
 *	| data_size = sizeof(struct c4_isp_params_awb_gains) +                |
 *	|              sizeof(struct c4_isp_params_awb_config);       |
 *	| +------------------------- data  ---------------------------------+ |
 *	| | +------------ struct c4_isp_params_awb_gains) ------------------+ |
 *	| | | +---------  struct c4_isp_params_block_header header -----+ | | |
 *	| | | | type = C4_ISP_PARAMS_BLOCK_AWB_GAINS;                   | | | |
 *	| | | | flags = C4_ISP_PARAMS_BLOCK_FL_NONE;                    | | | |
 *	| | | | size = sizeof(struct c4_isp_params_awb_gains);          | | | |
 *	| | | +---------------------------------------------------------+ | | |
 *	| | | gr_gain = ...;                                              | | |
 *	| | | r_gain = ...;                                               | | |
 *	| | | b_gain = ...;                                               | | |
 *	| | | gb_gain = ...;                                              | | |
 *	| | +------------------ struct c4_isp_params_awb_config ----------+ | |
 *	| | | +---------- struct c4_isp_param_block_header header ------+ | | |
 *	| | | | type = C4_ISP_PARAMS_BLOCK_AWB_CONFIG;                  | | | |
 *	| | | | flags = C4_ISP_PARAMS_BLOCK_FL_NONE;                    | | | |
 *	| | | | size = sizeof(struct c4_isp_params_awb_config)          | | | |
 *	| | | +---------------------------------------------------------+ | | |
 *	| | | tap_point = ...;                                            | | |
 *	| | | satur_vald = ...;                                           | | |
 *	| | | horiz_zones_num = ...;                                      | | |
 *	| | | vert_zones_num = ...;                                       | | |
 *	| | +-------------------------------------------------------------+ | |
 *	| +-----------------------------------------------------------------+ |
 *	+---------------------------------------------------------------------+
 *
 * @version: The C4 ISP parameters buffer version
 * @data_size: The C4 ISP configuration data effective size, excluding this
 *             header
 * @data: The C4 ISP configuration blocks data
 */
struct c4_isp_params_cfg {
	__u32 version;
	__u32 data_size;
	__u8 data[C4_ISP_PARAMS_MAX_SIZE];
};

#endif
